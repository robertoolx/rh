import React, { useState, useMemo, useEffect } from 'react';
import { Employee, UserRole, AlterationRecord, Attachment } from '../types';
import { Button } from './Button';
import { Input } from './Input';
import { formatCPF, validateCPF } from '../utils/validation';
import { FileViewerModal } from './FileViewerModal';

interface EmployeeDetailsProps {
  employee: Employee;
  onBack: () => void;
  canEdit?: boolean;
  onUpdate?: (updatedEmployee: Employee) => Promise<void>;
  onResetPassword?: (employeeId: string) => Promise<void>;
}

export const EmployeeDetails: React.FC<EmployeeDetailsProps> = ({ 
  employee, 
  onBack, 
  canEdit = false, 
  onUpdate, 
  onResetPassword 
}) => {
  // Default to current month YYYY-MM
  const getCurrentMonth = () => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  };

  const [selectedMonth, setSelectedMonth] = useState(getCurrentMonth());
  
  // Edit Mode States
  const [isEditing, setIsEditing] = useState(false);
  const [editFormData, setEditFormData] = useState<Partial<Employee>>({});
  const [editErrors, setEditErrors] = useState<Record<string, string>>({});
  const [isSaving, setIsSaving] = useState(false);
  
  // Attachment Viewing State
  const [viewingAttachment, setViewingAttachment] = useState<Attachment | null>(null);

  // Initialize edit form when entering edit mode or changing employee
  useEffect(() => {
    setEditFormData({
      name: employee.name,
      registrationNumber: employee.registrationNumber,
      cpf: employee.cpf,
      birthDate: employee.birthDate,
      admissionDate: employee.admissionDate,
      role: employee.role
    });
    setEditErrors({});
  }, [employee, isEditing]);

  // Helper to get total days in a month
  const getDaysInMonth = (yearMonth: string) => {
    const [year, month] = yearMonth.split('-').map(Number);
    return new Date(year, month, 0).getDate();
  };

  const stats = useMemo(() => {
    const totalDays = getDaysInMonth(selectedMonth);
    
    // Filter records for the selected month (For Lists and Calendar)
    const monthlyAlterations = (employee.alterationHistory || []).filter(record => 
      record.date.startsWith(selectedMonth)
    );

    const monthlySchedules = (employee.specialScheduleHistory || []).filter(record => 
      record.date.startsWith(selectedMonth)
    );
    
    const monthlyBankHours = (employee.bankHourHistory || []).filter(record =>
       record.date.startsWith(selectedMonth)
    );

    const monthlyTre = (employee.treHistory || []).filter(record =>
       record.workDate.startsWith(selectedMonth)
    );

    const monthlyNightShift = (employee.nightShiftHistory || []).filter(record =>
       record.month === selectedMonth
    );

    // Calculate deductions for Worked Days (Monthly context)
    let daysToDeduct = 0;
    let absenceCount = 0;

    monthlyAlterations.forEach(record => {
      if (record.type === 'Falta') {
        absenceCount++;
        daysToDeduct++;
      } else if (record.type === 'Atestado Médico') {
        daysToDeduct++;
      } else if (record.type === 'Férias') {
        daysToDeduct++;
      } else if (record.type === 'Abono') {
        if (record.abonoType === 'Doação de Sangue' || record.abonoType === 'TRE') {
          daysToDeduct++;
        }
      }
      // 'Folga' usually deducts from Bank Hours, not Worked Days count for payment
    });

    const daysWorked = Math.max(0, totalDays - daysToDeduct);
    
    // Calculate Special Schedule Usage (Monthly)
    const specialScheduleCost = monthlySchedules.reduce((acc, curr) => acc + curr.cost, 0);

    // --- GLOBAL BANK HOURS CALCULATION (All Time) ---
    const allBankCreditsMinutes = (employee.bankHourHistory || []).reduce((acc, curr) => {
       return acc + (curr.hours * 60) + curr.minutes;
    }, 0);

    const allBankDebitsMinutes = (employee.alterationHistory || []).reduce((acc, curr) => {
       if (curr.type === 'Folga') {
          return acc + ((curr.hours || 0) * 60) + (curr.minutes || 0);
       }
       return acc;
    }, 0);

    const globalNetBalanceMinutes = allBankCreditsMinutes - allBankDebitsMinutes;
    const isGlobalNegative = globalNetBalanceMinutes < 0;
    const absGlobalMinutes = Math.abs(globalNetBalanceMinutes);
    
    const globalBankHoursStr = `${isGlobalNegative ? '-' : '+'}${Math.floor(absGlobalMinutes / 60).toString().padStart(2, '0')}:${(absGlobalMinutes % 60).toString().padStart(2, '0')}`;

    // Calculate Night Shift Hours (Monthly)
    const totalNightShiftHours = monthlyNightShift.reduce((acc, curr) => acc + curr.hours, 0);

    // Calculate Total TRE Balance (All time)
    const totalTreCredits = (employee.treHistory || []).reduce((acc, curr) => acc + curr.creditDays, 0);
    // Usage is usually counted when an Abono of type TRE is used
    const totalTreUsed = (employee.alterationHistory || []).filter(r => r.type === 'Abono' && r.abonoType === 'TRE').length;
    const treBalance = totalTreCredits - totalTreUsed;

    return {
      daysWorked,
      totalDays,
      absenceCount,
      specialScheduleCost,
      globalBankHoursStr,
      isBankNegative: isGlobalNegative,
      totalNightShiftHours,
      treBalance,
      monthlyAlterations,
      monthlySchedules,
      monthlyBankHours,
      monthlyTre,
      monthlyNightShift
    };
  }, [selectedMonth, employee]);

  // Group alterations logic for display
  const groupedAlterations = useMemo(() => {
    const sorted = [...stats.monthlyAlterations].sort((a, b) => a.date.localeCompare(b.date));
    const groups: Array<AlterationRecord & { endDate: string }> = [];

    sorted.forEach((rec) => {
      const lastGroup = groups[groups.length - 1];

      // Check if consecutive day
      // Add 'T12:00:00' to avoid timezone issues when parsing
      const d1 = new Date(lastGroup?.endDate + 'T12:00:00');
      const d2 = new Date(rec.date + 'T12:00:00');
      const diffTime = Math.abs(d2.getTime() - d1.getTime());
      const isConsecutive = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) === 1;

      // Logic: Group if same type, same reason, same sub-type and dates are consecutive
      // Primarily for Férias and Atestado Médico, but works for others if logged consecutively
      if (lastGroup &&
          lastGroup.type === rec.type &&
          lastGroup.reason === rec.reason &&
          lastGroup.abonoType === rec.abonoType &&
          isConsecutive &&
          (rec.type === 'Férias' || rec.type === 'Atestado Médico')) {
          
          // Se o anexo atual for diferente do último, não agrupa, ou mantém o do último
          if (rec.attachment && !lastGroup.attachment) lastGroup.attachment = rec.attachment;

          lastGroup.endDate = rec.date;
      } else {
          groups.push({
              ...rec,
              endDate: rec.date
          });
      }
    });
    return groups;
  }, [stats.monthlyAlterations]);

  // Calendar Logic
  const renderCalendar = () => {
    const [yearStr, monthStr] = selectedMonth.split('-');
    const year = parseInt(yearStr);
    const month = parseInt(monthStr); // 1-12
    
    const firstDayOfMonth = new Date(year, month - 1, 1).getDay(); // 0 (Sun) - 6 (Sat)
    const daysInMonth = new Date(year, month, 0).getDate();

    const days = [];
    // Empty slots for previous month
    for (let i = 0; i < firstDayOfMonth; i++) {
      days.push(<div key={`empty-${i}`} className="h-24 bg-slate-50 border border-slate-100"></div>);
    }

    // Days of current month
    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${yearStr}-${monthStr}-${String(d).padStart(2, '0')}`;
      
      // Find events for this day
      const alteration = stats.monthlyAlterations.find(a => a.date === dateStr);
      const schedule = stats.monthlySchedules.find(s => s.date === dateStr);
      const bankHour = stats.monthlyBankHours.find(b => b.date === dateStr);
      const tre = stats.monthlyTre.find(t => t.workDate === dateStr);

      let bgColor = 'bg-white';
      let borderColor = 'border-slate-200';
      
      if (alteration) {
        if (alteration.type === 'Falta') {
            bgColor = 'bg-red-50';
            borderColor = 'border-red-200';
        } else if (alteration.type === 'Atestado Médico') {
            bgColor = 'bg-orange-50';
            borderColor = 'border-orange-200';
        } else if (alteration.type === 'Folga') {
            bgColor = 'bg-blue-50';
            borderColor = 'border-blue-200';
        } else if (alteration.type === 'Férias') {
            bgColor = 'bg-teal-50';
            borderColor = 'border-teal-200';
        } else {
            bgColor = 'bg-green-50'; // Abono
            borderColor = 'border-green-200';
        }
      }

      days.push(
        <div key={d} className={`h-24 border ${borderColor} ${bgColor} p-1 relative group overflow-hidden hover:overflow-visible hover:z-10 transition-all`}>
          <span className={`text-sm font-bold ${alteration ? 'text-slate-800' : 'text-slate-400'}`}>{d}</span>
          
          <div className="flex flex-col gap-1 mt-1">
            {alteration && (
              <span className={`text-[10px] px-1 rounded truncate w-full block ${
                alteration.type === 'Falta' ? 'bg-red-200 text-red-800' :
                alteration.type === 'Atestado Médico' ? 'bg-orange-200 text-orange-800' :
                alteration.type === 'Folga' ? 'bg-blue-200 text-blue-800' :
                alteration.type === 'Férias' ? 'bg-teal-200 text-teal-800' :
                'bg-green-200 text-green-800'
              }`}>
                {alteration.type === 'Abono' ? alteration.abonoType : alteration.type}
                {alteration.type === 'Folga' && alteration.hours !== undefined && ` (-${alteration.hours}h)`}
              </span>
            )}
            
            {schedule && (
              <span className="text-[10px] px-1 rounded bg-indigo-100 text-indigo-700 truncate w-full block">
                Escala: {schedule.duration}h
              </span>
            )}

            {bankHour && (
              <span className="text-[10px] px-1 rounded bg-emerald-100 text-emerald-700 truncate w-full block">
                BH: +{bankHour.hours}h
              </span>
            )}

            {tre && (
               <span className="text-[10px] px-1 rounded bg-yellow-100 text-yellow-700 truncate w-full block">
                TRE: {tre.creditDays}d
              </span>
            )}
          </div>
        </div>
      );
    }

    return days;
  };

  // Edit Handlers
  const handleEditChange = (field: keyof Employee, value: string) => {
    setEditFormData(prev => ({ ...prev, [field]: value }));
    // Clear error for field
    if (editErrors[field]) {
       setEditErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCPF(e.target.value);
    handleEditChange('cpf', formatted);
  };

  const handleSaveEdit = async () => {
    // Validation
    const errors: Record<string, string> = {};
    if (!editFormData.name?.trim()) errors.name = 'Nome é obrigatório';
    if (!editFormData.registrationNumber?.trim()) errors.registrationNumber = 'Matrícula é obrigatória';
    if (!editFormData.cpf?.trim()) errors.cpf = 'CPF é obrigatório';
    else if (!validateCPF(editFormData.cpf)) errors.cpf = 'CPF inválido';
    
    if (Object.keys(errors).length > 0) {
      setEditErrors(errors);
      return;
    }

    if (onUpdate) {
      try {
        setIsSaving(true);
        const updatedEmployee: Employee = {
          ...employee,
          ...editFormData as Employee
        };
        await onUpdate(updatedEmployee);
        setIsEditing(false);
      } catch (e) {
        alert('Erro ao salvar funcionário.');
      } finally {
        setIsSaving(false);
      }
    }
  };

  const handleResetPasswordClick = async () => {
    if (!onResetPassword) return;
    
    const confirm = window.confirm(
      `Tem certeza que deseja resetar a senha de ${employee.name}?\n\nA senha voltará a ser o padrão: GCMVV + Ano Atual.`
    );

    if (confirm) {
       await onResetPassword(employee.id);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString + 'T12:00:00').toLocaleDateString('pt-BR');
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
      {/* Header */}
      <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-800">{employee.name}</h2>
          <div className="flex gap-4 text-sm text-slate-500 mt-1">
            <span>Matrícula: {employee.registrationNumber}</span>
            <span>Permissão: {employee.role}</span>
          </div>
        </div>
        <Button variant="secondary" onClick={onBack} className="flex items-center gap-2">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="19" y1="12" x2="5" y2="12"></line>
            <polyline points="12 19 5 12 12 5"></polyline>
          </svg>
          Voltar
        </Button>
      </div>

      <div className="p-6">
        
        {/* Profile Info & Edit Section (Admin Only) */}
        <div className="mb-8 bg-slate-50 p-4 rounded-lg border border-slate-200">
          <div className="flex justify-between items-center mb-4">
             <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
               <svg className="w-5 h-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
               </svg>
               Dados Cadastrais
             </h3>
             {canEdit && !isEditing && (
                <div className="flex gap-2">
                   <Button variant="secondary" onClick={handleResetPasswordClick} className="text-xs bg-white hover:bg-slate-100">
                     <svg className="w-4 h-4 mr-1 inline" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                     </svg>
                     Resetar Senha
                   </Button>
                   <Button onClick={() => setIsEditing(true)} className="text-xs">
                     <svg className="w-4 h-4 mr-1 inline" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                     </svg>
                     Editar Dados
                   </Button>
                </div>
             )}
          </div>

          {isEditing ? (
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-fade-in bg-white p-4 rounded border border-blue-100">
                <Input label="Nome" value={editFormData.name || ''} onChange={e => handleEditChange('name', e.target.value)} error={editErrors.name} />
                <Input label="Matrícula" value={editFormData.registrationNumber || ''} onChange={e => handleEditChange('registrationNumber', e.target.value)} error={editErrors.registrationNumber} />
                <Input label="CPF" value={editFormData.cpf || ''} onChange={handleCpfChange} maxLength={14} error={editErrors.cpf} />
                <Input label="Nascimento" type="date" value={editFormData.birthDate || ''} onChange={e => handleEditChange('birthDate', e.target.value)} />
                <Input label="Admissão" type="date" value={editFormData.admissionDate || ''} onChange={e => handleEditChange('admissionDate', e.target.value)} />
                <div>
                   <label className="block text-sm font-medium text-slate-700 mb-1">Permissão</label>
                   <select 
                      className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-brand-500 bg-white"
                      value={editFormData.role}
                      onChange={e => handleEditChange('role', e.target.value as UserRole)}
                   >
                     <option value="Comum">Comum</option>
                     <option value="Administrador">Administrador</option>
                   </select>
                </div>
                <div className="md:col-span-2 flex justify-end gap-2 mt-2">
                   <Button variant="secondary" onClick={() => setIsEditing(false)}>Cancelar</Button>
                   <Button onClick={handleSaveEdit} disabled={isSaving}>{isSaving ? 'Salvando...' : 'Salvar Alterações'}</Button>
                </div>
             </div>
          ) : (
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div>
                  <span className="text-xs font-bold text-slate-400 uppercase">Nome Completo</span>
                  <p className="font-medium text-slate-800">{employee.name}</p>
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-400 uppercase">Matrícula</span>
                  <p className="font-medium text-slate-800">{employee.registrationNumber}</p>
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-400 uppercase">CPF</span>
                  <p className="font-medium text-slate-800">{employee.cpf || '-'}</p>
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-400 uppercase">Data de Nascimento</span>
                  <p className="font-medium text-slate-800">{employee.birthDate ? formatDate(employee.birthDate) : '-'}</p>
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-400 uppercase">Data de Admissão</span>
                  <p className="font-medium text-slate-800">{employee.admissionDate ? formatDate(employee.admissionDate) : '-'}</p>
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-400 uppercase">Perfil de Acesso</span>
                  <p className="font-medium text-slate-800">{employee.role}</p>
                </div>
             </div>
          )}
        </div>

        {/* Filter */}
        <div className="mb-8 p-4 bg-blue-50 border border-blue-100 rounded-lg flex items-center gap-4">
          <label htmlFor="month-select" className="font-medium text-blue-900">
            Selecione o Mês de Referência:
          </label>
          <input
            type="month"
            id="month-select"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
          />
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Dias Trabalhados</p>
            <p className="text-xl font-bold text-brand-600 mt-1">
              {stats.daysWorked} <span className="text-xs text-slate-400 font-normal">/ {stats.totalDays}</span>
            </p>
          </div>

          <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Faltas</p>
            <p className="text-xl font-bold text-red-600 mt-1">{stats.absenceCount}</p>
          </div>

          <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Escala Especial</p>
            <p className="text-xl font-bold text-indigo-600 mt-1">
              {stats.specialScheduleCost} <span className="text-xs text-slate-400 font-normal">/ 4</span>
            </p>
          </div>

          <div className="bg-emerald-50 p-3 rounded-lg border border-emerald-200 shadow-sm">
            <p className="text-[10px] font-bold text-emerald-700 uppercase tracking-wide">Banco de Horas (Saldo Total)</p>
            <p className={`text-xl font-bold mt-1 ${stats.isBankNegative ? 'text-red-600' : 'text-emerald-700'}`}>{stats.globalBankHoursStr}</p>
          </div>

          <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Adicional Noturno (Mensal)</p>
            <p className="text-xl font-bold text-purple-600 mt-1">{stats.totalNightShiftHours}h</p>
          </div>

          <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200 shadow-sm">
            <p className="text-[10px] font-bold text-yellow-700 uppercase tracking-wide">Saldo TRE (Total)</p>
            <p className="text-xl font-bold text-yellow-800 mt-1">{stats.treBalance} Dias</p>
          </div>
        </div>

        {/* Calendar Visualization */}
        <div className="mb-10">
          <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
            <svg className="w-5 h-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            Calendário de Atividades
          </h3>
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            {/* Week Headers */}
            <div className="grid grid-cols-7 bg-slate-100 border-b border-slate-200 text-center text-xs font-semibold text-slate-500 py-2">
              <div>Dom</div>
              <div>Seg</div>
              <div>Ter</div>
              <div>Qua</div>
              <div>Qui</div>
              <div>Sex</div>
              <div>Sáb</div>
            </div>
            {/* Days Grid */}
            <div className="grid grid-cols-7 bg-slate-50">
               {renderCalendar()}
            </div>
          </div>
           <div className="flex gap-4 mt-2 text-xs text-slate-500 justify-end">
             <div className="flex items-center gap-1"><div className="w-3 h-3 bg-red-200 rounded"></div> Falta</div>
             <div className="flex items-center gap-1"><div className="w-3 h-3 bg-orange-200 rounded"></div> Atestado</div>
             <div className="flex items-center gap-1"><div className="w-3 h-3 bg-teal-200 rounded"></div> Férias</div>
             <div className="flex items-center gap-1"><div className="w-3 h-3 bg-green-200 rounded"></div> Abono</div>
             <div className="flex items-center gap-1"><div className="w-3 h-3 bg-blue-200 rounded"></div> Folga</div>
             <div className="flex items-center gap-1"><div className="w-3 h-3 bg-indigo-100 rounded"></div> Escala</div>
           </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Alterations History List */}
          <div>
            <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
              <svg className="w-5 h-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              Histórico de Alterações ({groupedAlterations.length} eventos)
            </h3>
            {groupedAlterations.length === 0 ? (
              <p className="text-sm text-slate-500 italic">Nenhuma alteração lançada neste mês.</p>
            ) : (
              <div className="space-y-3">
                {groupedAlterations.map((group, idx) => (
                  <div key={idx} className="p-3 border border-slate-200 rounded-md bg-slate-50 text-sm">
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-semibold text-slate-700">
                        {/* Data: Se início e fim forem iguais, mostra um, senão mostra o intervalo */}
                        {group.date === group.endDate 
                          ? formatDate(group.date)
                          : `${formatDate(group.date)} até ${formatDate(group.endDate)}`
                        }
                        {' - '}{group.type} 
                        {group.abonoType ? ` (${group.abonoType})` : ''}
                      </span>
                      {group.type === 'Folga' && group.hours !== undefined && (
                         <span className="text-xs bg-red-100 text-red-800 px-2 py-0.5 rounded font-medium">
                            -{group.hours}h {group.minutes}m
                         </span>
                      )}
                    </div>
                    <p className="text-slate-600">{group.reason}</p>
                    {group.attachment && (
                      <div className="mt-2 text-xs flex items-center gap-1">
                        <button 
                          onClick={() => setViewingAttachment(group.attachment || null)}
                          className="flex items-center gap-1 text-brand-600 hover:text-brand-800 hover:underline font-medium transition-colors"
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                          </svg>
                          Ver anexo: {group.attachment.name}
                        </button>
                      </div>
                    )}
                    <div className="mt-2 text-[10px] text-slate-400 text-right border-t border-slate-100 pt-1">
                       Lançado por: {group.createdBy || 'Sistema'}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-8">
              {/* Special Schedule History List */}
              <div>
                <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                  <svg className="w-5 h-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Escalas Especiais ({stats.monthlySchedules.length})
                </h3>
                {stats.monthlySchedules.length === 0 ? (
                  <p className="text-sm text-slate-500 italic">Nenhuma escala especial neste mês.</p>
                ) : (
                  <div className="space-y-3">
                    {stats.monthlySchedules.map((rec) => (
                      <div key={rec.id} className="p-3 border border-slate-200 rounded-md bg-slate-50 text-sm">
                        <div className="flex justify-between items-start">
                          <span className="font-semibold text-slate-700">
                            {formatDate(rec.date)}
                          </span>
                          <span className={`px-2 py-0.5 rounded text-xs font-medium ${rec.duration === 12 ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}`}>
                            {rec.duration} Horas (Custo: {rec.cost})
                          </span>
                        </div>
                        <p className="text-slate-600 mt-1">
                          Horário: {rec.startTime} às {rec.endTime}
                        </p>
                        <div className="mt-2 text-[10px] text-slate-400 text-right border-t border-slate-100 pt-1">
                           Lançado por: {rec.createdBy || 'Sistema'}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Bank Hours History List */}
              <div>
                <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                  <svg className="w-5 h-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Lançamentos Banco de Horas ({stats.monthlyBankHours.length})
                </h3>
                {stats.monthlyBankHours.length === 0 ? (
                  <p className="text-sm text-slate-500 italic">Nenhum lançamento neste mês.</p>
                ) : (
                  <div className="space-y-3">
                    {stats.monthlyBankHours.map((rec) => (
                      <div key={rec.id} className="p-3 border border-slate-200 rounded-md bg-slate-50 text-sm">
                         <div className="flex justify-between items-start">
                          <span className="font-semibold text-slate-700">
                            {formatDate(rec.date)}
                          </span>
                          <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded text-xs font-medium">
                            +{rec.hours}h {rec.minutes}m
                          </span>
                        </div>
                        <p className="text-slate-600 mt-1">{rec.reason}</p>
                        <div className="mt-2 text-[10px] text-slate-400 text-right border-t border-slate-100 pt-1">
                           Lançado por: {rec.createdBy || 'Sistema'}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* TRE History List */}
              <div>
                <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                  <svg className="w-5 h-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                  </svg>
                  Histórico TRE ({stats.monthlyTre.length})
                </h3>
                {stats.monthlyTre.length === 0 ? (
                  <p className="text-sm text-slate-500 italic">Nenhum registro de TRE neste mês.</p>
                ) : (
                  <div className="space-y-3">
                    {stats.monthlyTre.map((rec) => (
                      <div key={rec.id} className="p-3 border border-slate-200 rounded-md bg-slate-50 text-sm">
                         <div className="flex justify-between items-start">
                          <span className="font-semibold text-slate-700">
                            Data: {formatDate(rec.workDate)}
                          </span>
                          <span className="bg-yellow-100 text-yellow-800 px-2 py-0.5 rounded text-xs font-medium">
                            {rec.creditDays} Dias Crédito
                          </span>
                        </div>
                        <p className="text-slate-600 mt-1">{rec.observation}</p>
                        <div className="mt-2 text-[10px] text-slate-400 text-right border-t border-slate-100 pt-1">
                           Lançado por: {rec.createdBy || 'Sistema'}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Night Shift History List */}
              <div>
                <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                  <svg className="w-5 h-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                  </svg>
                  Histórico Adicional Noturno ({stats.monthlyNightShift.length})
                </h3>
                {stats.monthlyNightShift.length === 0 ? (
                  <p className="text-sm text-slate-500 italic">Nenhum registro de adicional noturno neste mês.</p>
                ) : (
                  <div className="space-y-3">
                    {stats.monthlyNightShift.map((rec) => (
                      <div key={rec.id} className="p-3 border border-slate-200 rounded-md bg-slate-50 text-sm">
                         <div className="flex justify-between items-center">
                          <span className="font-semibold text-slate-700">
                             Lançamento Mensal
                          </span>
                          <span className="bg-purple-100 text-purple-800 px-2 py-0.5 rounded text-xs font-medium">
                            {rec.hours} Horas
                          </span>
                        </div>
                        <div className="mt-2 text-[10px] text-slate-400 text-right border-t border-slate-100 pt-1">
                           Lançado por: {rec.createdBy || 'Sistema'}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
          </div>
        </div>

        {/* Modal de Visualização de Arquivos */}
        <FileViewerModal 
          isOpen={!!viewingAttachment} 
          onClose={() => setViewingAttachment(null)} 
          attachment={viewingAttachment} 
        />
      </div>
    </div>
  );
};