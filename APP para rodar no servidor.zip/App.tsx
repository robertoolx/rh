import React, { useState, useEffect } from 'react';
import { Employee, MonthlyAttendance, AlterationRecord, AlterationType, AbonoType, Attachment, SpecialScheduleRecord, BankHourRecord, TreRecord, NightShiftRecord } from './types';
import { fileService } from './services/fileService';
import { EmployeeForm } from './components/EmployeeForm';
import { EmployeeList } from './components/EmployeeList';
import { EmployeeDetails } from './components/EmployeeDetails';
import { AlterationForm } from './components/AlterationForm';
import { SpecialScheduleForm } from './components/SpecialScheduleForm';
import { BankHourForm } from './components/BankHourForm';
import { TreForm } from './components/TreForm';
import { NightShiftForm } from './components/NightShiftForm';
import { FrequencyReport } from './components/FrequencyReport';
import { BackupPage } from './components/BackupPage';
import { Button } from './components/Button';
import { LoginPage } from './components/LoginPage';
import { ChangePasswordModal } from './components/ChangePasswordModal';

function App() {
  const [isFolderSelected, setIsFolderSelected] = useState(false);
  const [folderName, setFolderName] = useState<string | null>(null);
  const [savedFolderName, setSavedFolderName] = useState<string | null>(null);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [status, setStatus] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  
  // Auth state
  const [currentUser, setCurrentUser] = useState<Employee | 'super-admin' | null>(null);

  // Navigation state
  const [activeTab, setActiveTab] = useState<'new' | 'list' | 'alteration' | 'special' | 'bank' | 'tre' | 'night' | 'report' | 'backup'>('list');
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);

  // Password Modal State
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);

  // Check for saved session OR Local API on mount
  useEffect(() => {
    const checkSession = async () => {
      // First check if Local API is available (Automatic Mode)
      const isLocal = await fileService.checkLocalServer();
      if (isLocal) {
         setFolderName("Pasta Local (./Data)");
         setIsFolderSelected(true);
         refreshData(); // Auto load data
         return;
      }

      // If not, try to restore browser handle
      const savedName = await fileService.restoreSession();
      if (savedName) {
        setSavedFolderName(savedName);
      }
    };
    checkSession();
  }, []);

  // Helper to get current admin ID for logs
  const getCurrentAdminId = (): string => {
    if (!currentUser) return 'Sistema';
    if (currentUser === 'super-admin') return 'Super Admin';
    return currentUser.registrationNumber;
  };

  const handleSelectDirectory = async () => {
    try {
      setError(null);
      const name = await fileService.selectDirectory();
      setFolderName(name);
      setIsFolderSelected(true);
      await refreshData();
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      }
    }
  };

  const handleReconnect = async () => {
    try {
      setError(null);
      const name = await fileService.reconnectDirectory();
      setFolderName(name);
      setIsFolderSelected(true);
      await refreshData();
    } catch (err: any) {
      console.error(err);
      setError('Não foi possível reconectar à pasta. Selecione-a novamente.');
      // If reconnection fails, clear the saved state so user has to select again
      setSavedFolderName(null);
    }
  };

  const refreshData = async () => {
    try {
      setStatus('Carregando...');
      const data = await fileService.loadEmployees();
      setEmployees(data);
      setStatus(`Dados carregados: ${data.length} registros.`);
    } catch (err) {
      console.error(err);
      setError('Erro ao ler arquivo. Verifique se o arquivo está corrompido ou se você tem permissão.');
    } finally {
      setTimeout(() => setStatus(''), 3000);
    }
  };

  const handleLogin = (user: Employee | 'super-admin') => {
    setCurrentUser(user);
    // If it's a common user, immediately show their details and nothing else
    if (user !== 'super-admin' && user.role === 'Comum') {
      setSelectedEmployee(user);
    } else {
      // Admin goes to list by default
      setActiveTab('list');
      setSelectedEmployee(null);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setSelectedEmployee(null);
    setIsPasswordModalOpen(false);
  };

  const handleChangePassword = async (currentPass: string, newPass: string) => {
    // ADMIN PASSWORD CHANGE LOGIC
    if (currentUser === 'super-admin') {
       try {
         const stored = await fileService.loadAdminPassword();
         const actual = stored || 'RHSERVICE141629042205'; // Fallback to hardcoded

         if (currentPass !== actual) {
            throw new Error('A senha atual está incorreta.');
         }

         await fileService.saveAdminPassword(newPass);
         setStatus('Senha do Administrador alterada com sucesso!');
       } catch (err: any) {
         throw new Error(err.message || 'Erro ao salvar senha do admin.');
       } finally {
         setTimeout(() => setStatus(''), 3000);
       }
       return;
    }

    // NORMAL USER PASSWORD CHANGE LOGIC
    if (!currentUser) return;

    // Logic similar to LoginPage to verify current password
    const currentYear = new Date().getFullYear();
    const defaultPassword = `GCMVV${currentYear}`;
    const userStoredPass = currentUser.password || defaultPassword;

    if (currentPass !== userStoredPass) {
      throw new Error('A senha atual está incorreta.');
    }

    // Update User
    const updatedUser = { ...currentUser, password: newPass };
    
    // Update List
    const updatedEmployees = employees.map(emp => 
      emp.id === currentUser.id ? updatedUser : emp
    );

    try {
      await fileService.saveEmployees(updatedEmployees);
      setEmployees(updatedEmployees);
      setCurrentUser(updatedUser);
      setStatus('Senha alterada com sucesso!');
    } catch (err) {
      throw new Error('Erro ao salvar nova senha no disco.');
    } finally {
      setTimeout(() => setStatus(''), 3000);
    }
  };

  // ADMIN ACTION: Update Employee Profile
  const handleUpdateEmployee = async (updatedEmployee: Employee) => {
    try {
      setStatus('Atualizando cadastro...');
      const updatedList = employees.map(emp => 
        emp.id === updatedEmployee.id ? updatedEmployee : emp
      );
      
      await fileService.saveEmployees(updatedList);
      setEmployees(updatedList);
      setSelectedEmployee(updatedEmployee); // Update the view
      setStatus('Cadastro atualizado com sucesso!');
    } catch (err) {
      console.error(err);
      throw new Error('Erro ao salvar alterações.');
    } finally {
      setTimeout(() => setStatus(''), 3000);
    }
  };

  // ADMIN ACTION: Reset Password
  const handleResetPassword = async (employeeId: string) => {
    try {
      setStatus('Resetando senha...');
      const currentYear = new Date().getFullYear();
      const defaultPassword = `GCMVV${currentYear}`;

      const updatedList = employees.map(emp => {
        if (emp.id === employeeId) {
          return { ...emp, password: defaultPassword };
        }
        return emp;
      });

      await fileService.saveEmployees(updatedList);
      setEmployees(updatedList);
      setStatus(`Senha resetada para o padrão: ${defaultPassword}`);
    } catch (err) {
      console.error(err);
      throw new Error('Erro ao resetar senha.');
    } finally {
      setTimeout(() => setStatus(''), 5000);
    }
  };

  const handleAddEmployee = async (data: Omit<Employee, 'id' | 'createdAt'>) => {
    try {
      setStatus('Salvando...');
      
      const currentYear = new Date().getFullYear();
      const defaultPassword = `GCMVV${currentYear}`;

      const newEmployee: Employee = {
        ...data,
        id: crypto.randomUUID(),
        password: defaultPassword, // Auto-generate default password
        createdAt: new Date().toISOString(),
        attendance: {},
        alterationHistory: [],
        specialScheduleHistory: [],
        bankHourHistory: [],
        treHistory: [],
        nightShiftHistory: []
      };

      const updatedList = [...employees, newEmployee];
      await fileService.saveEmployees(updatedList);
      
      setEmployees(updatedList);
      setStatus(`Funcionário salvo! Senha gerada: ${defaultPassword}`);
      setActiveTab('list');
    } catch (err) {
      console.error(err);
      setError('Erro ao salvar no disco. Verifique as permissões.');
    } finally {
      setTimeout(() => setStatus(''), 5000);
    }
  };

  const handleRegisterAlteration = async (
    employeeId: string, 
    date: string, 
    type: AlterationType, 
    abonoType: AbonoType | undefined, 
    reason: string,
    attachment: Attachment | undefined,
    endDate?: string,
    hours?: number,
    minutes?: number
  ) => {
    try {
      setStatus('Lançando alteração...');
      const author = getCurrentAdminId();
      
      const updatedList = employees.map(emp => {
        if (emp.id === employeeId) {
          const newRecords: AlterationRecord[] = [];

          if ((type === 'Atestado Médico' || type === 'Férias') && endDate) {
             const start = new Date(date);
             const end = new Date(endDate);
             
             for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
                const dateString = d.toISOString().split('T')[0];
                newRecords.push({
                  id: crypto.randomUUID(),
                  date: dateString,
                  type,
                  abonoType,
                  reason: `${reason} (Período: ${new Date(date).toLocaleDateString('pt-BR')} a ${new Date(endDate).toLocaleDateString('pt-BR')})`,
                  attachment,
                  createdBy: author
                });
             }
          } else {
             newRecords.push({
               id: crypto.randomUUID(),
               date,
               type,
               abonoType,
               reason,
               attachment,
               hours,
               minutes,
               createdBy: author
             });
          }

          const history = [...(emp.alterationHistory || []), ...newRecords];

          return {
            ...emp,
            alterationHistory: history
          };
        }
        return emp;
      });

      await fileService.saveEmployees(updatedList);
      setEmployees(updatedList);
      setStatus(`Alteração "${type}" lançada com sucesso!`);
    } catch (err) {
      console.error(err);
      setError('Erro ao lançar alteração.');
    } finally {
      setTimeout(() => setStatus(''), 3000);
    }
  };

  const handleRegisterSpecialSchedule = async (
    employeeId: string,
    date: string,
    startTime: string,
    endTime: string,
    duration: 6 | 12,
    cost: 1 | 2
  ) => {
    try {
      setStatus('Registrando escala especial...');
      const author = getCurrentAdminId();
      
      const updatedList = employees.map(emp => {
        if (emp.id === employeeId) {
          const newRecord: SpecialScheduleRecord = {
            id: crypto.randomUUID(),
            date,
            startTime,
            endTime,
            duration,
            cost,
            createdBy: author
          };
          
          const history = [...(emp.specialScheduleHistory || []), newRecord];
          
          return {
            ...emp,
            specialScheduleHistory: history
          };
        }
        return emp;
      });

      await fileService.saveEmployees(updatedList);
      setEmployees(updatedList);
      setStatus('Escala especial registrada com sucesso!');
    } catch (err) {
      console.error(err);
      setError('Erro ao registrar escala especial.');
    } finally {
      setTimeout(() => setStatus(''), 3000);
    }
  };

  const handleRegisterBankHour = async (
    employeeId: string,
    date: string,
    hours: number,
    minutes: number,
    reason: string
  ) => {
    try {
      setStatus('Registrando banco de horas...');
      const author = getCurrentAdminId();
      
      const updatedList = employees.map(emp => {
        if (emp.id === employeeId) {
          const newRecord: BankHourRecord = {
            id: crypto.randomUUID(),
            date,
            hours,
            minutes,
            reason,
            createdBy: author
          };
          
          const history = [...(emp.bankHourHistory || []), newRecord];
          
          return {
            ...emp,
            bankHourHistory: history
          };
        }
        return emp;
      });

      await fileService.saveEmployees(updatedList);
      setEmployees(updatedList);
      setStatus('Banco de horas atualizado com sucesso!');
    } catch (err) {
      console.error(err);
      setError('Erro ao registrar banco de horas.');
    } finally {
      setTimeout(() => setStatus(''), 3000);
    }
  };

  const handleRegisterTre = async (
    employeeId: string,
    workDate: string,
    creditDays: number,
    observation: string
  ) => {
    try {
      setStatus('Registrando TRE...');
      const author = getCurrentAdminId();
      
      const updatedList = employees.map(emp => {
        if (emp.id === employeeId) {
          const newRecord: TreRecord = {
            id: crypto.randomUUID(),
            workDate,
            creditDays,
            observation,
            createdBy: author
          };
          
          const history = [...(emp.treHistory || []), newRecord];
          
          return {
            ...emp,
            treHistory: history
          };
        }
        return emp;
      });

      await fileService.saveEmployees(updatedList);
      setEmployees(updatedList);
      setStatus('Registro TRE realizado com sucesso!');
    } catch (err) {
      console.error(err);
      setError('Erro ao registrar TRE.');
    } finally {
      setTimeout(() => setStatus(''), 3000);
    }
  };

  const handleRegisterNightShift = async (
    employeeId: string,
    month: string,
    hours: number
  ) => {
    try {
      setStatus('Registrando Adicional Noturno...');
      const author = getCurrentAdminId();
      
      const updatedList = employees.map(emp => {
        if (emp.id === employeeId) {
          const newRecord: NightShiftRecord = {
            id: crypto.randomUUID(),
            month,
            hours,
            createdBy: author
          };
          
          const history = [...(emp.nightShiftHistory || []), newRecord];
          
          return {
            ...emp,
            nightShiftHistory: history
          };
        }
        return emp;
      });

      await fileService.saveEmployees(updatedList);
      setEmployees(updatedList);
      setStatus('Adicional Noturno registrado com sucesso!');
    } catch (err) {
      console.error(err);
      setError('Erro ao registrar Adicional Noturno.');
    } finally {
      setTimeout(() => setStatus(''), 3000);
    }
  };

  const handleImportData = async (data: Employee[]) => {
      try {
        setStatus('Salvando dados restaurados...');
        await fileService.saveEmployees(data);
        setEmployees(data);
        setStatus('Banco de dados restaurado com sucesso!');
        setActiveTab('list');
      } catch (err) {
        console.error(err);
        setError('Erro ao salvar os dados restaurados.');
      } finally {
        setTimeout(() => setStatus(''), 3000);
      }
  };

  const handleViewDetails = (employee: Employee) => {
    setSelectedEmployee(employee);
  };

  const handleBackToList = () => {
    // If common user, "back" actually logs them out because they have no list view
    if (currentUser !== 'super-admin' && currentUser?.role === 'Comum') {
      // Do nothing, hide back button in component or handle logout
      return; 
    }
    setSelectedEmployee(null);
  };

  const SidebarItem = ({ id, label, icon }: { id: 'new' | 'list' | 'alteration' | 'special' | 'bank' | 'tre' | 'night' | 'report' | 'backup', label: string, icon: React.ReactNode }) => (
    <button
      onClick={() => {
        setActiveTab(id);
        setSelectedEmployee(null);
      }}
      className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium transition-colors rounded-md mb-1
        ${activeTab === id && !selectedEmployee
          ? 'bg-brand-50 text-brand-700 border-l-4 border-brand-600' 
          : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 border-l-4 border-transparent'
        }`}
    >
      {icon}
      {label}
    </button>
  );

  // --- Render Flow ---

  // 1. No folder selected -> Show Intro
  if (!isFolderSelected) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-xl shadow-lg p-8 border border-slate-200 text-center">
            {error && (
               <div className="mb-4 p-3 bg-red-50 text-red-700 rounded border border-red-200 text-sm">
                  {error}
               </div>
            )}
            <div className="bg-brand-50 p-6 rounded-full mb-6 mx-auto w-24 h-24 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-brand-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M5 19a2 2 0 01-2-2V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v1M5 19h14a2 2 0 002-2v-5a2 2 0 00-2-2H9a2 2 0 00-2 2v5a2 2 0 01-2 2z" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mb-3">Bem-vindo ao Gestão RH</h2>
            <p className="text-slate-500 mb-8 leading-relaxed text-sm">
              O sistema tentará se conectar à pasta <strong>./Data</strong> automaticamente.<br/>
              Se você está vendo esta tela, selecione a pasta manualmente ou verifique se iniciou pelo arquivo .BAT
            </p>
            
            {savedFolderName && (
              <div className="mb-4 animate-fade-in">
                <Button onClick={handleReconnect} className="w-full py-3 mb-2 bg-brand-600 hover:bg-brand-700 shadow-md">
                   Reconectar à pasta: {savedFolderName}
                </Button>
                <p className="text-xs text-slate-400">O navegador pedirá uma confirmação rápida.</p>
              </div>
            )}

            <Button onClick={handleSelectDirectory} variant="secondary" className="w-full py-3 text-lg border border-slate-300">
              Selecionar Pasta Manualmente
            </Button>
        </div>
      </div>
    );
  }

  // 2. Folder selected but not logged in -> Show Login
  if (!currentUser) {
    return <LoginPage employees={employees} onLogin={handleLogin} />;
  }

  const isAdmin = currentUser === 'super-admin' || currentUser.role === 'Administrador';

  // 3. Logged in -> Show App
  return (
    <div className="min-h-screen bg-slate-100 pb-12 print:bg-white print:pb-0">
      {/* Header */}
      <header className="bg-brand-900 text-white shadow-lg sticky top-0 z-20 print:hidden">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center gap-3">
             <div className="bg-white/10 p-2 rounded-lg">
                <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
             </div>
             <div>
                <h1 className="text-xl font-bold tracking-tight">Gestão RH</h1>
                <p className="text-brand-100 text-xs">
                  {currentUser === 'super-admin' ? 'Super Admin' : `${currentUser.name} (${currentUser.role})`}
                </p>
             </div>
          </div>
          
          <div className="flex items-center gap-4">
            {/* UPDATED LOGOUT BUTTON: Red color for visibility */}
            <Button onClick={handleLogout} className="text-xs px-3 py-1 bg-red-600 text-white border-none hover:bg-red-700 shadow-sm font-bold">
               Sair
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8 print:p-0 print:max-w-full">
        {error && (
          <div className="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded shadow-sm flex justify-between items-center print:hidden">
            <p className="text-sm text-red-700">{error}</p>
            <button onClick={() => setError(null)} className="text-red-400 hover:text-red-500">
               <span className="sr-only">Fechar</span>
               <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                 <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L10 8.586 5.707 4.293a1 1 0 010-1.414z" clipRule="evenodd" />
               </svg>
            </button>
          </div>
        )}

        <div className="flex flex-col md:flex-row gap-8">
            {/* Sidebar - Visible for Everyone (filtered by role) */}
            <aside className="w-full md:w-64 flex-shrink-0 print:hidden">
                 <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden sticky top-24">
                    <div className="p-4 bg-slate-50 border-b border-slate-200">
                       <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Menu Principal</p>
                    </div>
                    <nav className="p-2 space-y-1">
                       {/* ADMIN ITEMS */}
                       {isAdmin && (
                         <>
                           <SidebarItem 
                              id="new" 
                              label="Novo Funcionário" 
                              icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" /></svg>} 
                           />
                           <SidebarItem 
                              id="list" 
                              label="Consultar Funcionários" 
                              icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>} 
                           />
                           <SidebarItem 
                              id="alteration" 
                              label="Lançar Alteração" 
                              icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>} 
                           />
                           <SidebarItem 
                              id="special" 
                              label="Lançar Escala Especial" 
                              icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} 
                           />
                           <SidebarItem 
                              id="bank" 
                              label="Lançar Banco de Horas" 
                              icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} 
                           />
                           <SidebarItem 
                              id="tre" 
                              label="Lançar TRE" 
                              icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>} 
                           />
                           <SidebarItem 
                              id="night" 
                              label="Lançar Adicional Noturno" 
                              icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>} 
                           />
                           <SidebarItem 
                              id="report" 
                              label="Relatório de Frequência" 
                              icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>} 
                           />
                         </>
                       )}
                       
                       <div className="pt-4 mt-4 border-t border-slate-200 space-y-1">
                           {/* ENABLED FOR EVERYONE */}
                           <button
                             onClick={() => setIsPasswordModalOpen(true)}
                             className="w-full flex items-center gap-3 px-4 py-3 text-sm font-medium transition-colors rounded-md mb-1 text-slate-600 hover:bg-slate-50 hover:text-slate-900 border-l-4 border-transparent text-left"
                           >
                             <svg className="w-5 h-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                             </svg>
                             Alterar Minha Senha
                           </button>

                          {isAdmin && (
                            <SidebarItem 
                               id="backup" 
                               label="Dados e Backup" 
                               icon={<svg className="w-5 h-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" /></svg>} 
                            />
                          )}
                       </div>
                    </nav>
                 </div>
              </aside>

            {/* Main Content */}
            <div className="flex-1 w-full">
               {status && (
                  <div className={`mb-4 p-4 rounded-md border flex items-center gap-3 animate-fade-in print:hidden ${status.includes('sucesso') ? 'bg-green-50 border-green-200 text-green-700' : 'bg-blue-50 border-blue-200 text-blue-700'}`}>
                     {status}
                  </div>
               )}

               {/* View Logic */}
               {selectedEmployee ? (
                 <EmployeeDetails 
                    employee={selectedEmployee} 
                    onBack={isAdmin ? handleBackToList : () => {}} // Common users cannot go back to list
                    canEdit={isAdmin} // Pass permission to edit
                    onUpdate={isAdmin ? handleUpdateEmployee : undefined}
                    onResetPassword={isAdmin ? handleResetPassword : undefined}
                 />
               ) : isAdmin ? (
                 // ADMIN VIEWS
                 activeTab === 'new' ? (
                    <div className="max-w-4xl mx-auto">
                       <h2 className="text-2xl font-bold text-slate-800 mb-6">Novo Funcionário</h2>
                       <EmployeeForm onSave={handleAddEmployee} disabled={!!status && status !== 'Salvando...'} />
                    </div>
                 ) : activeTab === 'alteration' ? (
                     <div className="max-w-4xl mx-auto">
                       <h2 className="text-2xl font-bold text-slate-800 mb-6">Lançar Alteração</h2>
                       <AlterationForm employees={employees} onSave={handleRegisterAlteration} disabled={!!status && status !== 'Lançando alteração...'} />
                     </div>
                 ) : activeTab === 'special' ? (
                     <div className="max-w-4xl mx-auto">
                       <h2 className="text-2xl font-bold text-slate-800 mb-6">Lançar Escala Especial</h2>
                       <SpecialScheduleForm employees={employees} onSave={handleRegisterSpecialSchedule} disabled={!!status && status !== 'Registrando escala especial...'} />
                     </div>
                 ) : activeTab === 'bank' ? (
                     <div className="max-w-4xl mx-auto">
                       <h2 className="text-2xl font-bold text-slate-800 mb-6">Lançar Banco de Horas</h2>
                       <BankHourForm employees={employees} onSave={handleRegisterBankHour} disabled={!!status && status !== 'Registrando banco de horas...'} />
                     </div>
                 ) : activeTab === 'tre' ? (
                     <div className="max-w-4xl mx-auto">
                       <h2 className="text-2xl font-bold text-slate-800 mb-6">Lançar TRE</h2>
                       <TreForm employees={employees} onSave={handleRegisterTre} disabled={!!status && status !== 'Registrando TRE...'} />
                     </div>
                 ) : activeTab === 'night' ? (
                     <div className="max-w-4xl mx-auto">
                       <h2 className="text-2xl font-bold text-slate-800 mb-6">Lançar Adicional Noturno</h2>
                       <NightShiftForm employees={employees} onSave={handleRegisterNightShift} disabled={!!status && status !== 'Registrando Adicional Noturno...'} />
                     </div>
                 ) : activeTab === 'report' ? (
                     <div className="max-w-full mx-auto">
                       <FrequencyReport employees={employees} />
                     </div>
                 ) : activeTab === 'backup' ? (
                     <div className="max-w-4xl mx-auto">
                       <BackupPage employees={employees} onImportSuccess={handleImportData} />
                     </div>
                 ) : (
                    <div className="h-full">
                       <div className="flex justify-between items-center mb-6">
                          <div className="flex items-center gap-3">
                            <h2 className="text-2xl font-bold text-slate-800">Consultar Funcionários</h2>
                            <span className="inline-flex items-center justify-center px-3 py-1 rounded-full bg-brand-100 text-brand-800 text-sm font-medium">
                              Total: {employees.length}
                            </span>
                          </div>
                          <Button variant="secondary" onClick={refreshData}>Atualizar Lista</Button>
                       </div>
                       <EmployeeList employees={employees} onViewDetails={handleViewDetails} />
                    </div>
                 )
               ) : (
                 // COMMON USER FALLBACK (Should catch if state is inconsistent, though selectedEmployee covers most cases)
                 <div className="text-center p-10">Carregando seus dados...</div>
               )}
            </div>
          </div>
      </main>
      
      <ChangePasswordModal 
        isOpen={isPasswordModalOpen}
        onClose={() => setIsPasswordModalOpen(false)}
        onSave={handleChangePassword}
      />
    </div>
  );
}

export default App;