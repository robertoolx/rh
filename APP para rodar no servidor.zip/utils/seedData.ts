import { Employee } from '../types';

const RAW_DATA = `
9961593 Abner Nunes Pereira 20/04/1988 05/09/2011
29793 Adeir Cardoso dos Santos 26/05/1975 20/12/2013
29734 Ademilson de Souza Pereira 29/08/1973 20/12/2013
9924213 Adriano Barcelos de Mesquita 26/09/1981 04/03/2009
9923950 Adriano Cintra Correia 13/06/1982 03/03/2009
9930132 Adriano Expedito Silva 19/03/1979 01/07/2009
835706 Adriano Roriz 19/09/1969 09/04/2009
29696 Agostinho Smarzaro Filho 22/06/1991 20/12/2013
9079122 Alcy da Silva Santos 20/11/1960 11/06/2008
9930876 Aldemir Felix 04/02/1973 16/07/2009
29408 Alessandra Cardoso da Silva 25/06/1983 20/12/2013
9925155 Alessandro Alves Costa 15/09/1975 16/03/2009
9083669 Alexsandro Soares Zardim 30/11/1980 03/11/2008
10007043 Allisson Bruno Brito Ferreira 17/06/2001 04/03/2024
71803 Altivo Maciel Barros Silva 22/05/1974 14/07/2016
29653 Amarildo Meira dos Santos 28/05/1988 20/12/2013
931713 Americo Dias Proximozer 02/12/1966 16/06/2008
29637 Ana Cláudia Tavares Rezende 10/01/1970 20/12/2013
10007045 Ana Lidia Narciso Alves Manhaes 04/08/1991 04/03/2024
98345 Anderson Gaigher 22/10/1983 14/07/2016
29890 Anderson Salomão 25/04/1973 20/12/2013
97284 Anderson Siqueira Gastaldi 01/03/1981 14/07/2016
29700 André de Assis Higino e Gorza 27/12/1978 20/12/2013
9924159 Andre Marciano de Souza 04/05/1982 04/03/2009
10007047 Andressa Gomes Cavalcanti 05/04/1988 04/03/2024
54739 Antonio Carlos Rodrigues Junior 13/01/1988 28/12/2018
9082948 Antonio Nelio Jubini Rangel 07/05/1986 06/10/2008
9925112 Aureo Bonizioli Vieira 09/06/1972 16/03/2009
10007048 Beatriz Munoz D Almeida E Souza 11/01/1991 04/03/2024
114090 Breno Dadalto Arrivabene Aragao 30/11/1990 04/03/2024
98256 Bruno dos Santos Alvarenga 03/04/1978 14/07/2016
53279 Bruno Paes Lorenzoni 21/03/1989 28/12/2018
10007051 Caio Avance Rocha 20/09/1995 11/03/2024
9927077 Caio Tacito Lima 20/10/1965 23/04/2009
9923802 Carlos Alberto Souza Brito 07/08/1976 27/02/2009
9930396 Carlos Augusto Ribeiro 22/08/1968 07/07/2009
9925082 Carlos Augusto Vericio Pereira 02/02/1982 16/03/2009
29378 Carlos Douglas Santiago Monfardini 25/02/1975 20/12/2013
29882 Carlos Eduardo Rosa 21/11/1978 20/12/2013
97624 Carlos Elton Elbert Junior 08/01/1975 14/07/2016
29220 Carlos Henrique Botto Coutinho 13/02/1983 20/12/2013
96660 Carlos Magno Alves Ferreira 04/02/1984 14/07/2016
29939 Carlos Raynaud Biluca 28/04/1978 20/12/2013
98302 Carolina Roubach de Andrade 24/08/1984 19/07/2016
10007080 Caroline Barros Belonia 10/01/1988 04/03/2024
97926 Caroline Gomes Pereira 18/07/1995 14/07/2016
45691 Celso Monteiro Costa Junior 08/09/1984 14/07/2016
10007053 Christian William Vieira da Paixao 03/12/1991 13/03/2024
9926518 Clarisse Senatore Cardoso 14/02/1989 13/04/2009
29858 Claudecir Bazilio da Silva 18/02/1976 20/12/2013
9952160 Claudio Silva de Matos 28/11/1975 19/10/2010
98639 Cleber Silva Senatore 23/07/1996 22/07/2016
10007063 Daniel Alves de Souza Gobbo 23/11/1986 11/03/2024
96598 Daniel Cruz do Nascimento 05/10/1982 14/07/2016
9083774 Daniel Lima Pires 28/09/1983 21/11/2008
96970 Daniel Siqueira Junior 28/06/1990 14/07/2016
97055 Darzila de Fátima Marcate Martins Carminati 17/09/1987 14/07/2016
98140 Daylson Ferreira Andrade 22/07/1980 14/07/2016
10007067 Deivid Cardoso da Silva 11/05/1998 04/03/2024
97020 Diego Augusto Pereira 11/11/1991 14/07/2016
97870 Diego Luiz Nunes Amorim 13/02/1980 14/07/2016
29386 Dilnei Garcia da Silva 28/07/1980 20/12/2013
10007079 Diogo Ramos Falco 20/06/1994 04/03/2024
9079165 Durval Gomes da Silva 12/01/1969 11/06/2008
98191 Edeilton Pereira de Souza 28/03/1986 14/07/2016
9961445 Eder Batista 23/11/1982 01/09/2011
9927085 Eder Effegem Falcao 07/06/1979 17/08/2011
97365 Edgar Ferri Martins 06/04/1987 14/07/2016
9924280 Edilene Dias da Silva Franca 08/04/1982 05/03/2009
29840 Ednilson Bispo de Andrade 04/03/1961 20/12/2013
811815 Edson Albertino 31/08/1970 06/10/2008
9959408 Eduardo Andre Nobre de Aguiar 02/03/1979 05/07/2011
10007068 Eduardo Viganor Silva 28/12/1988 11/03/2024
97446 Eliane Hand Onofre 14/02/1986 14/07/2016
9080783 Elias Rodrigues Barbosa 17/10/1970 01/08/2008
969516 Elisangela Fraga de Oliveira da Silva 07/02/1979 08/04/2009
9971815 Elton Batista 23/11/1982 02/04/2012
9973206 Eraldo Cabral Pereira 04/06/1967 17/04/2012
811840 Ernivaldo Westphal 27/09/1960 09/12/2008
9079084 Esalmar Silva Morais 06/11/1979 11/06/2008
29483 Everson Oliveira da Cruz 28/12/1980 20/12/2013
9079890 Fabio Barcellos 04/05/1976 18/06/2008
29505 Fábio Dias 24/11/1976 20/12/2013
97586 Fabio Martinelli de Oliveira 03/08/1972 14/07/2016
9961097 Fábio Roberto Azevedo Defendenti 03/06/1981 15/08/2011
9083421 Fabio Roberto Mota 14/03/1981 20/10/2008
29920 Fabio Wiedenhoeft Barros 13/07/1978 20/12/2013
9924205 Fabricio Leite Machado 05/04/1976 04/03/2009
9923837 Fabricio Pelis Gusmao Silva 07/04/1982 26/02/2009
10007069 Fabriscio Soares Delai 01/12/1995 04/03/2024
9961119 Felipe Jacob Schultz 08/12/1989 16/08/2011
10007078 Felipe Thomaz dos Santos 13/01/1989 11/03/2024
97594 Fernanda Colli Bihain 28/06/1991 14/07/2016
97381 Fernanda Daudt Rodrigues 22/05/1988 14/07/2016
97551 Fernanda Mariano Macieira 20/10/1983 14/07/2016
98027 Filipe Resende Lima 04/04/1981 15/07/2016
10007088 Flavio de Paula Barbosa Filho 03/02/1996 11/03/2024
97969 Flavio Henrique Santos de Barcellos 03/12/1978 14/07/2016
97900 Franciny Silva da Vitória 05/12/1988 14/07/2016
962945 Francisco Antonio Machado Froes 09/05/1957 13/04/2009
9971904 Francisco Carlos de Almeida Rocha 23/05/1979 03/04/2012
35114 Francisco Gimenes Batista 27/08/1970 17/02/2014
9926453 Francisco Pereira de Andrade 11/03/1978 09/04/2009
9927115 Franz Wagner de Oliveira Stinghel 27/07/1989 27/04/2009
97721 Gabriel Duprat Bessa Leite 23/06/1993 14/07/2016
29203 Gedean José da Silva 29/03/1977 23/12/2013
35106 Gelcimário Norata da Silva 07/04/1981 17/02/2014
96679 George Carlos Gomes Santos 03/03/1980 14/07/2016
98604 George Wildne Freitas da Silva 02/06/1993 22/07/2016
29181 Gilcemir Nunes do Carmo 24/08/1972 23/12/2013
811866 Gilmar Pelluchi Fraga 03/04/1960 16/03/2009
350389 Gilson Alves de Souza 26/02/1959 01/10/1987
97403 Gilson Rei 03/10/1980 14/07/2016
31887 Gisele de Freitas Oliveira 19/01/1988 20/01/2014
11274 Giselle Carneiro Figueiredo 21/12/1985 20/12/2013
97330 Giuliano da Conceição Pereira 27/04/1995 14/07/2016
10007093 Guilherme dos Santos Ferreira 21/09/2000 04/03/2024
53333 Guilherme Pinheiro Colle 16/10/1986 28/12/2018
9926593 Gustavo Machado Barcelos 21/02/1981 14/04/2009
9936289 Hadassa Botto Fiorot Alves 27/04/1984 14/07/2016
54801 Hamanda Cristina Jesus Pereira 06/10/1988 28/12/2018
97306 Heber Felipe Lacerda Calo 18/03/1989 14/07/2016
10007090 Henrique de Oliveira Kreitlow 23/01/1994 04/03/2024
97667 Higor Magalhaes Lira 28/07/1989 14/07/2016
10007094 Higor Sousa de Paulo 18/10/1989 04/03/2024
10007095 Iago Potrich 16/09/1992 04/03/2024
811831 Igor Brandao Mageski 30/11/1980 01/07/2009
10007096 Igor Franklim Saturnino Dias 19/10/1992 11/03/2024
98078 Ikaro Carvalho Veloso 04/03/1987 15/07/2016
98272 Ildison Romerio de Oliveira Martins 27/04/1972 14/07/2016
10007098 Isabelle Scandian Oliveira 22/05/1995 04/03/2024
10007101 Islane Santos da Silva Cerqueira 10/07/1996 13/03/2024
97470 Ismael Carlos Silva 30/10/1989 14/07/2016
10007105 Israel Giri Lima 02/10/1989 07/03/2024
100250 Israel Pereira Davila 31/03/1990 10/08/2016
9996435 Iuri de Souza Silva 09/12/1987 20/12/2013
29823 Ivineu Cézar do Rosário Araújo 10/04/1983 20/12/2013
29246 Jader de Almeida Bastos 04/06/1974 20/12/2013
9084061 Jailton Tavares Rangel 07/08/1971 02/12/2008
10007122 Jean Carlo Cunha Dias 20/11/1986 05/03/2024
97748 Jean Carlos Alves Smiderli 13/04/1985 14/07/2016
96954 Jefferson Bessa Lopes 22/06/1983 14/07/2016
97861 Jefferson Bonfim Silva 06/11/1988 14/07/2016
10007110 Jessica Rossmam Zambon 13/08/1993 11/03/2024
9959394 Jhonatan Crizanto da Silva 21/09/1985 05/07/2011
9084240 João Batista Gomes 25/03/1973 15/12/2008
521248 Joao Luiz Caramuru Filho 02/07/1979 28/11/2008
98019 João Paulo Bittencourt Pereira Epichin 19/08/1990 14/07/2016
98590 João Renato Portugal da Silva 07/05/1975 21/07/2016
53449 Joao Silva Costa Junior 25/03/1988 28/12/2018
10007112 Joas Bahiense Santos 05/06/1991 04/03/2024
9083995 Jobson Meirelles de Abreu 08/08/1964 02/12/2008
9924337 Joel Rodrigues de Araujo 01/08/1965 05/03/2009
30481 Joel Theodore Paranhos Bucsan 16/04/1983 10/01/2014
96857 Johnnatan Feu de Oliveira 04/04/1982 14/07/2016
1004042 Johny Rios Manhaes 02/04/1989 28/12/2018
53465 Jorge Cardoso Teixeira 19/08/1982 28/12/2018
29670 José Amarildo Louzada 14/05/1971 20/12/2013
97934 José Felix da Silva Junior 09/04/1979 14/07/2016
9923853 José Roberto Belmonte 29/10/1981 02/03/2009
10007099 Josemar Guilherme Vieira Rosa 06/01/1992 05/03/2024
28746 Josias Viana de Andrade 02/03/1969 01/10/1987
10007076 Josuel de Oliveira Cardoso 01/06/1987 05/03/2024
10007087 Juan da Silva Pereira 05/05/2000 04/03/2024
9960058 Julio Cesar Fae Simoes 19/07/1989 14/07/2016
98655 Julio dos Santos Carlos 01/04/1980 21/07/2016
10007089 Junior Galvani Coco 22/09/1992 04/03/2024
96997 Junior Guedes dos Santos 02/07/1992 14/07/2016
10007108 Kaio Colodetti Paiva 26/12/1998 04/03/2024
10007115 Kalyxto Lima de Souza 13/01/1991 04/03/2024
54593 Karly Nascimento da Silva Aquino 02/11/1987 28/12/2018
53490 Kellen Teixeira 09/11/1993 28/12/2018
10007121 Ketelyn Menezes Amorim 30/12/1997 13/03/2024
97411 Lais Mongin Barbosa 16/05/1990 14/07/2016
29955 Landson Tavares da Silva 23/12/1981 20/12/2013
10007124 Lara Paiva da Silva 11/01/1989 04/03/2024
96881 Larissa Lopes dos Santos 09/03/1994 15/07/2016
9082956 Lauro Bittencourt 04/06/1967 06/10/2008
9084754 Leandro Alvarenga Rhein 02/09/1985 16/12/2008
53627 Leandro Alves Ferreira 25/09/1986 28/12/2018
822485 Leandro Modolo Izidoro 21/07/1983 08/04/2009
10007123 Leonardo Caetano de Andrade 03/07/2000 04/03/2024
9972897 Leonardo do Nascimento Santos 21/03/1983 13/04/2012
811718 Leonardo Morozesck do Nascimento 02/06/1977 11/06/2008
930040 Leonardo Silva Borini 15/12/1976 27/04/2009
10007119 Leonardo Xavier 19/05/1988 04/03/2024
29491 Lígia Monteiro Vazzoler 26/12/1988 20/12/2013
97845 Liss Micheli Deccottignies Scardua Vaz 09/04/1973 14/07/2016
97462 Livia Herdy Rodrigues Verli 28/11/1986 14/07/2016
9929959 Lorena Machado Berger 08/01/1982 30/06/2009
10007118 Lorrainy Marinho Oliveira 08/09/1993 11/03/2024
9927476 Lucas Francisco dos Santos 25/04/1964 08/05/2009
10007116 Lucas Hosken Moraes 24/02/1992 13/03/2024
10007113 Lucas Martins de Souza 19/12/1996 04/03/2024
97438 Lucas Silva Siqueira 10/05/1993 14/07/2016
97373 Luciana Nogueira Pereira 10/02/1975 14/07/2016
9924256 Luciano Fraga Gonçalves 11/02/1978 17/02/2009
9964177 Luciano Paulo da Ros 27/04/1970 25/10/2011
29157 Lucimar Rodrigues Mendes 21/09/1967 20/12/2013
97560 Ludmilla de Andrade Escouto 10/11/1988 14/07/2016
29718 Luiz Guilherme Valadares Costa Simoes 20/04/1985 20/12/2013
96911 Maikel Garcia dos Santos 20/01/1986 14/07/2016
10007111 Manuela Nascimento Alves 12/01/1998 04/03/2024
98647 Marcelo Alves 25/11/1974 21/07/2016
29564 Marcelo Francisco de Souza da Paz 10/03/1977 20/12/2013
52973 Marcilio Bispo de Carvalho 17/08/1986 28/12/2018
9923748 Márcio Dutra Ramos 25/12/1975 26/02/2009
9945237 Márcio Roberto de Souza Ferreira 06/03/1978 20/12/2013
98531 Marcioglei Pereira 25/09/1974 20/07/2016
97292 Marcos Antonio de Oliveira 01/09/1972 14/07/2016
9923888 Marcos Antonio Ribeiro Nascimento 29/10/1980 26/02/2009
97632 Marcos da Silva Pinto Junior 03/07/1995 14/07/2016
9931589 Marcos de Souza Ferreira 16/10/1961 29/07/2009
10007100 Marcos Henrique da Silva Oliveira 10/10/1996 04/03/2024
10007147 Marcos Tonon Wernersbach 07/03/1998 11/03/2024
9080287 Marcus Francisco de Araujo 20/01/1956 01/07/2008
10007091 Marcus Vinicius Goncalves de Paula 17/07/1989 11/03/2024
97268 Marcus Vinicius Pires Silva 17/08/1994 14/07/2016
30066 Mariana Veronesi Vieira Medeiros 02/12/1992 20/12/2013
10007073 Marilia Ferreira da Silva 30/01/1989 04/03/2024
10007072 Marlon Silva Garcia 08/02/1994 04/03/2024
97420 Mateus Nogueira Rodrigues do Nascimento 09/11/1996 14/07/2016
9083804 Mauro Lucio Machado 09/08/1971 24/11/2008
820156 Michele Sa de Almeida Amaral 02/12/1980 07/07/2009
98159 Miguel Angelo Maues Senna Santos de Martin 28/02/1984 14/07/2016
96768 Monique Lima de Aguiar 09/10/1986 14/07/2016
98116 Natalia de Paula Fraga Malini 04/11/1983 14/07/2016
53066 Natalia Mendes Ferreira 14/10/1996 28/12/2018
9959955 Neemias Santos Miranda 15/05/1978 14/07/2011
57061 Nicodemus Sousa Souto 28/08/1981 07/01/2019
10007071 Nicole Frederico Hoffmann 22/04/1997 04/03/2024
97098 Nuno Caliman Gouvea de Souza 22/07/1989 14/07/2016
9082930 Orcide Marques da Silva 05/06/1965 06/10/2008
98183 Otavio Costa Neto 10/04/1995 14/07/2016
29521 Pablison Vinicio Ferreira 21/09/1977 20/12/2013
9921583 Patrick da Silva Oliveira 11/07/1985 23/01/2014
9959700 Paulo de Souza Freitas 01/06/1957 11/07/2011
96709 Paulo Henrique dos Santos 04/03/1981 14/07/2016
9924027 Paulo Vieira Junior 07/05/1979 26/02/2009
966410 Priscila Moreira Muniz 06/07/1976 09/04/2009
97829 Priscila Oliveira Sousa 04/06/1987 14/07/2016
29335 Queli Cristina Nascimento Lobarde Coutinho 30/05/1982 20/12/2013
9955950 Rafael da Hora Borges 07/01/1986 22/03/2011
29645 Rafael da Silva Janiques 26/06/1980 20/12/2013
96865 Rafael Leão Ramos 18/10/1984 14/07/2016
53104 Rafael Silveira Morellato 11/09/1981 28/12/2018
97276 Raílla Suellem de Oliveira Marinho 29/08/1992 14/07/2016
98167 Raiza Lorrania Murari da Cunha 12/11/1989 14/07/2016
10007066 Ramara Rita de Jesus Andrade 15/09/1994 06/03/2024
97128 Ramon Afonso de Oliveira 15/03/1990 14/07/2016
10007064 Ramon Alves de Freitas 11/09/1991 04/03/2024
29343 Raphael Herzog da Silva 04/06/1980 20/12/2013
10007062 Raphael Rodrigues do Vale 29/09/1992 04/03/2024
9931090 Raul Luiz Martins da Silva 22/08/1978 23/07/2009
97810 Reginaldo Luiz da Penha Dias 07/02/1983 14/07/2016
9079149 Reinaldo Gonçalves de Freitas 26/06/1972 11/06/2008
10007061 Renan Carlos Valiati Barreto 02/05/1991 11/03/2024
10007060 Renan Duarte Gomes Mariano 14/02/1997 04/03/2024
97349 Renato Alexandre Alves Messias 28/09/1977 14/07/2016
29807 Renato Meneli 11/02/1975 20/12/2013
9079173 Rhainer Barroso do Nascimento 20/12/1985 11/06/2008
98060 Ricardo Joaquim Coutinho 20/10/1975 14/07/2016
98051 Ricardo Jose de Mattos 20/12/1989 14/07/2016
97071 Ricardo Saibert Oliveira 05/07/1992 14/07/2016
10007077 Richelly Junia de Andrade Freitas 07/03/1993 04/03/2024
97217 Roberta Rosa Rocha Montibeler 07/07/1989 14/07/2016
9956140 Roberta Vidigal Campbell Munzer 15/10/1987 14/07/2016
29432 Roberto Costa 05/02/1975 20/12/2013
9083901 Roberto Genuario de Lima Junior 24/03/1979 03/12/2008
962937 Roberto Rosa de Oliveira 24/02/1959 29/06/2011
29831 Robson dos Santos Sacramento 06/11/1989 20/12/2013
9971920 Robson Fernandes Passos 05/09/1983 03/04/2012
29580 Rodrigo Alves Rocha 13/05/1986 20/12/2013
9965998 Rodrigo Cossetti Carvalho 07/01/1986 17/01/2012
10007059 Rodrigo Fonseca da Conceicao 20/06/1993 04/03/2024
29262 Rodrigo Guilherme Roque 07/06/1982 18/12/2013
10007126 Rogerio Arlindo Cardoso Netto 13/03/1992 11/03/2024
9924043 Rogerio Lourencini Costa 24/01/1987 27/02/2009
10007058 Rogerio Oliveira Araujo Junior 12/09/1998 04/03/2024
96750 Ronaldo Coutinho de Oliveira 31/08/1980 14/07/2016
96733 Ronaldo Dias Lepaus 24/07/1985 14/07/2016
31895 Rondinelli Gonçalves Gomes 15/01/1981 16/01/2014
29661 Roney Nascimento da Silva 26/09/1986 20/12/2013
97578 Ronivaldo Penedo de Lima 18/12/1977 14/07/2016
9930361 Rubens da Costa Lima 25/10/1974 06/07/2009
10007102 Rubiany Santana Teixeira Scopel 28/03/1998 04/03/2024
97608 Rusley Hilário Medeiros Miorim 03/07/1989 14/07/2016
97543 Ruy Barbosa Junior 07/03/1984 14/07/2016
353841 Samuel Vicente Barcelos Nunes 01/05/1965 19/09/2008
9965580 Sandro Rodrigo de Lima Gomes 12/10/1976 02/01/2012
29459 Sergio de Oliveira 07/02/1978 20/12/2013
9925171 Sidnei Lords Moreira 01/12/1977 16/03/2009
29556 Silverio Moura da Silva 28/03/1984 20/12/2013
97683 Silvia Renata Segatto Santos Nascimento 02/04/1977 14/07/2016
9926470 Steves Nascimento Araujo 23/03/1973 13/04/2009
29300 Suzana dos Santos Ferreira 24/07/1983 20/12/2013
903124 Tarcisio Rocha 18/05/1978 22/07/2009
10007057 Thaynan da Silva 28/09/1990 04/03/2024
10007056 Thiago Campos dos Santos 17/08/1992 04/03/2024
96830 Thiago dos Santos Telles 16/01/1985 14/07/2016
97799 Thiago Moreira Macedo 22/04/1985 14/07/2016
29319 Thiago Nylander Veronez 04/04/1983 20/12/2013
9930167 Thiago Ribeiro dos Santos 25/12/1981 01/07/2009
96989 Thiago Vendramini Barreto 09/03/1988 14/07/2016
97063 Tiago Boa Morte Laures 03/07/1986 14/07/2016
30007 Tiago Garcia Andrade Ferreira 17/07/1991 20/12/2013
29289 Valdileia Souza dos Santos Cardoso 20/11/1979 20/12/2013
29599 Valeska Rangel Ferreira 20/07/1981 20/12/2013
9966366 Valmir Tavares de Carvalho 21/02/1967 27/01/2012
9929878 Valter Siqueira 28/07/1980 27/07/2009
1002317 Valter Souza de Melo 14/12/1951 15/04/2009
9926666 Vanderlei Soares Zardim 26/02/1971 15/04/2009
9924426 Vanilda Primo da Silva Valadares 21/04/1979 06/03/2009
35084 Versiléa Vieira da Rocha 28/07/1972 28/01/2014
9994882 Victor Henrique Amorim Moutinho 19/04/1992 28/12/2018
10007125 Vinicius Barcelos Pereira Araujo 27/02/1997 04/03/2024
10007055 Vinicius Machado Nunes 17/04/1999 04/03/2024
96792 Vitor Coelho Muniz 09/08/1985 14/07/2016
98566 Vitor Regattieri Santos 10/05/1987 28/07/2016
29270 Wagner Lopes Sotele Moschen 09/06/1973 20/12/2013
29360 Wagner Luis Guimarães 03/05/1983 20/12/2013
97152 Wagner Mattos do Nascimento 24/05/1980 14/07/2016
9960635 Wagner Motta Aigner 02/01/1983 11/08/2011
811700 Walter das Neves Fraga 05/06/1966 08/04/2009
30511 Washington dos Anjos 11/10/1976 07/01/2014
29572 Washington José Carvalho dos Santos Junior 12/07/1983 20/12/2013
353345 Washington Luiz Monteiro Barcellos 27/07/1975 20/12/2013
96784 Weberton Ritchi Lessa 18/05/1984 14/07/2016
96946 Welington de Freitas Dias 01/09/1982 14/07/2016
9971807 Wellington Lima de Morais 28/03/1967 30/03/2012
29351 Wesley Patrocinio Felipe 21/03/1985 20/12/2013
53112 Wesllen Rickson Pereira Rocha 14/01/1988 28/12/2018
10007054 Willian Almeida Cirino 01/06/1988 11/03/2024
98108 Willian Gomes de Oliveira 16/05/1988 14/07/2016
9974920 Willis Moreira Barcellos dos Santos 19/03/1988 02/05/2012
29440 Wilson Ferreira das Neves Martins 30/10/1979 20/12/2013
10007049 Wilson Mendonca Alves 10/04/1994 04/03/2024
10007046 Witiney Correa Sampaio 04/03/1993 04/03/2024
10007044 Yan Sant Ana Coelho 25/03/1993 04/03/2024
10007081 Yuri Marcio Pianzola Soave 24/02/1992 11/03/2024
53260 Zenilson Borges da Silva 24/04/1985 28/12/2018
`;

export const getSeedData = (): Employee[] => {
  const currentYear = new Date().getFullYear();
  const defaultPassword = `GCMVV${currentYear}`;
  
  const formatDate = (dateStr: string) => {
    // Convert DD/MM/YYYY to YYYY-MM-DD
    if (!dateStr) return '';
    const parts = dateStr.split('/');
    if (parts.length !== 3) return '';
    return `${parts[2]}-${parts[1]}-${parts[0]}`;
  };

  return RAW_DATA.trim().split('\n').filter(line => line.trim().length > 0).map(line => {
    const parts = line.trim().split(/\s+/);
    
    // First element is Registration Number
    const regNumber = parts[0];
    
    // Last element is Admission Date
    const admissionDateRaw = parts.pop() || '';
    
    // Second to last is Birth Date
    const birthDateRaw = parts.pop() || '';
    
    // Remainder is Name
    const name = parts.slice(1).join(' ');

    const employee: Employee = {
      id: crypto.randomUUID(),
      name: name,
      registrationNumber: regNumber,
      cpf: '', // Leave empty as requested
      birthDate: formatDate(birthDateRaw),
      admissionDate: formatDate(admissionDateRaw),
      role: 'Comum',
      createdAt: new Date().toISOString(),
      password: defaultPassword,
      attendance: {},
      alterationHistory: [],
      specialScheduleHistory: [],
      bankHourHistory: [],
      treHistory: [],
      nightShiftHistory: []
    };

    return employee;
  });
};
