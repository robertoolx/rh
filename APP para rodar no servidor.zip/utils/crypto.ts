// A static key derivation salt/passphrase for this application instance.
// In a local-only app without backend, this obfuscates the data preventing 
// casual text-editor viewing, satisfying the requirement.
const APP_SECRET = "GCMVV_INTERNAL_SECURE_KEY_2025_RH_LOCAL";

const getKey = async () => {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    "raw",
    enc.encode(APP_SECRET),
    { name: "PBKDF2" },
    false,
    ["deriveKey"]
  );

  return window.crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: enc.encode("GCMVV_SALT_V1"),
      iterations: 100000,
      hash: "SHA-256",
    },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
};

export const encryptData = async (data: any): Promise<string> => {
  try {
    const key = await getKey();
    const enc = new TextEncoder();
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const jsonStr = JSON.stringify(data);
    
    const encryptedContent = await window.crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv: iv,
      },
      key,
      enc.encode(jsonStr)
    );

    // Combine IV and Ciphertext and convert to Base64
    const encryptedArray = new Uint8Array(encryptedContent);
    const combined = new Uint8Array(iv.length + encryptedArray.length);
    combined.set(iv);
    combined.set(encryptedArray, iv.length);

    // Convert to Base64 string
    let binary = '';
    const len = combined.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(combined[i]);
    }
    return `ENC:${btoa(binary)}`;
  } catch (e) {
    console.error("Encryption failed", e);
    throw new Error("Falha na criptografia dos dados.");
  }
};

export const decryptData = async (encryptedString: string): Promise<any> => {
  try {
    // Check if it has our prefix
    if (!encryptedString.startsWith('ENC:')) {
      throw new Error("Formato de arquivo inválido ou não criptografado.");
    }

    const base64 = encryptedString.slice(4); // Remove 'ENC:'
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    // Extract IV and Ciphertext
    const iv = bytes.slice(0, 12);
    const data = bytes.slice(12);
    const key = await getKey();

    const decryptedContent = await window.crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv: iv,
      },
      key,
      data
    );

    const dec = new TextDecoder();
    return JSON.parse(dec.decode(decryptedContent));
  } catch (e) {
    console.error("Decryption failed", e);
    throw new Error("Senha incorreta ou arquivo corrompido.");
  }
};