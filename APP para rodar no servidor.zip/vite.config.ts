import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Plugin customizado para simular um Backend Local
const localFileSystemPlugin = () => {
  return {
    name: 'local-file-system-api',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        // Endpoint para verificar status
        if (req.url === '/api/status' && req.method === 'GET') {
          const dataDir = path.resolve(__dirname, 'Data');
          if (!fs.existsSync(dataDir)) {
            try { fs.mkdirSync(dataDir); } catch (e) { console.error(e); }
          }
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ status: 'ok', path: dataDir }));
          return;
        }

        // --- ENDPOINTS DE FUNCIONÁRIOS ---

        // Endpoint para ler dados
        if (req.url === '/api/load' && req.method === 'GET') {
          const filePath = path.resolve(__dirname, 'Data', 'employees.json');
          
          if (!fs.existsSync(filePath)) {
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify([])); // Retorna array vazio se não existir
            return;
          }

          try {
            const data = fs.readFileSync(filePath, 'utf-8');
            res.setHeader('Content-Type', 'application/json');
            res.end(data);
          } catch (err) {
            res.statusCode = 500;
            res.end(JSON.stringify({ error: 'Erro ao ler arquivo' }));
          }
          return;
        }

        // Endpoint para salvar dados (com backup)
        if (req.url === '/api/save' && req.method === 'POST') {
          const filePath = path.resolve(__dirname, 'Data', 'employees.json');
          const dataDir = path.resolve(__dirname, 'Data');
          const backupDir = path.resolve(dataDir, 'Backups');
          
          if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);
          if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir);

          // Lógica de Backup Automático
          try {
            if (fs.existsSync(filePath)) {
              const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
              const backupPath = path.resolve(backupDir, `employees-${timestamp}.json`);
              fs.copyFileSync(filePath, backupPath);

              const files = fs.readdirSync(backupDir);
              const backupFiles = files.filter(f => f.startsWith('employees-') && f.endsWith('.json'));
              if (backupFiles.length > 50) {
                backupFiles.sort();
                const filesToDelete = backupFiles.slice(0, backupFiles.length - 50);
                filesToDelete.forEach(file => {
                  fs.unlinkSync(path.resolve(backupDir, file));
                });
              }
            }
          } catch (backupErr) {
            console.error('Erro ao criar backup automático:', backupErr);
          }

          let body = '';
          req.on('data', chunk => { body += chunk.toString(); });
          req.on('end', () => {
            try {
              fs.writeFileSync(filePath, body);
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ success: true }));
            } catch (err) {
              res.statusCode = 500;
              res.end(JSON.stringify({ error: 'Erro ao salvar arquivo' }));
            }
          });
          return;
        }

        // --- ENDPOINTS DO ADMIN (NOVO) ---

        // Ler senha do admin
        if (req.url === '/api/admin/load' && req.method === 'GET') {
            const filePath = path.resolve(__dirname, 'Data', 'admin.json');
            if (!fs.existsSync(filePath)) {
                res.setHeader('Content-Type', 'application/json');
                res.end(JSON.stringify({ password: null }));
                return;
            }
            try {
                const data = fs.readFileSync(filePath, 'utf-8');
                res.setHeader('Content-Type', 'application/json');
                res.end(data);
            } catch (err) {
                res.end(JSON.stringify({ password: null }));
            }
            return;
        }

        // Salvar senha do admin
        if (req.url === '/api/admin/save' && req.method === 'POST') {
            const filePath = path.resolve(__dirname, 'Data', 'admin.json');
            const dataDir = path.resolve(__dirname, 'Data');
            if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);

            let body = '';
            req.on('data', chunk => { body += chunk.toString(); });
            req.on('end', () => {
                try {
                    fs.writeFileSync(filePath, body);
                    res.setHeader('Content-Type', 'application/json');
                    res.end(JSON.stringify({ success: true }));
                } catch (err) {
                    res.statusCode = 500;
                    res.end(JSON.stringify({ error: 'Erro ao salvar admin' }));
                }
            });
            return;
        }

        next();
      });
    },
  };
};

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react(), localFileSystemPlugin()],
})