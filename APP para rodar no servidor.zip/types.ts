
export interface MonthlyAttendance {
  daysWorked: number;
  absences: number;
  bankHours: string;
  specialSchedule: string;
}

export type AlterationType = 'Abono' | 'Atestado Médico' | 'Falta' | 'Folga' | 'Férias';
export type AbonoType = 'Audiência' | 'Aniversário' | 'Doação de Sangue' | 'Preventivo' | 'TRE';
export type UserRole = 'Comum' | 'Administrador';

export interface Attachment {
  name: string;
  mimeType: string;
  data: string; // Base64 string
}

export interface AlterationRecord {
  id: string;
  date: string;
  type: AlterationType;
  abonoType?: AbonoType;
  reason: string;
  attachment?: Attachment;
  // New fields for 'Folga' (Bank Hour Deduction)
  hours?: number;
  minutes?: number;
  createdBy?: string; // Matrícula do admin que lançou
}

export interface SpecialScheduleRecord {
  id: string;
  date: string;
  startTime: string;
  endTime: string;
  duration: 6 | 12;
  cost: 1 | 2; // 1 slot for 6h, 2 slots for 12h
  createdBy?: string;
}

export interface BankHourRecord {
  id: string;
  date: string;
  hours: number;
  minutes: number;
  reason: string;
  createdBy?: string;
}

export interface TreRecord {
  id: string;
  workDate: string;
  creditDays: number;
  observation: string;
  createdBy?: string;
}

export interface NightShiftRecord {
  id: string;
  month: string; // Format: YYYY-MM
  hours: number;
  createdBy?: string;
}

export interface Employee {
  id: string;
  name: string;
  registrationNumber: string; // Matrícula (Login)
  password?: string; // Senha
  cpf: string;
  birthDate: string;
  admissionDate: string;
  role: UserRole; // New permission field
  createdAt: string;
  attendance?: Record<string, MonthlyAttendance>; // Key format: "YYYY-MM"
  alterationHistory?: AlterationRecord[];
  specialScheduleHistory?: SpecialScheduleRecord[];
  bankHourHistory?: BankHourRecord[];
  treHistory?: TreRecord[];
  nightShiftHistory?: NightShiftRecord[];
}

export interface FileSystemContextType {
  hasHandle: boolean;
  directoryName: string | null;
  selectDirectory: () => Promise<void>;
  saveData: (employees: Employee[]) => Promise<void>;
  loadData: () => Promise<Employee[]>;
  error: string | null;
}
