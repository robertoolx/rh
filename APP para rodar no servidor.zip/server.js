import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Configuração de Caminhos (compatível com ES Modules)
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
// Aumenta limite para suportar anexos (imagens/PDFs) em Base64 grandes
app.use(express.text({ limit: '50mb' })); 
app.use(express.json({ limit: '50mb' }));

// Garante que as pastas de dados existam
const dataDir = path.resolve(__dirname, 'Data');
const backupDir = path.resolve(dataDir, 'Backups');

if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);
if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir);

// --- API ENDPOINTS (Cópia da lógica do vite.config.ts) ---

// 1. Status Check
app.get('/api/status', (req, res) => {
  res.json({ status: 'ok', path: dataDir, mode: 'production' });
});

// 2. Load Employees
app.get('/api/load', (req, res) => {
  const filePath = path.resolve(dataDir, 'employees.json');
  if (!fs.existsSync(filePath)) {
    return res.json([]);
  }
  try {
    const data = fs.readFileSync(filePath, 'utf-8');
    // Se for JSON puro, envia como JSON. Se for criptografado (string), envia como texto.
    try {
        const json = JSON.parse(data);
        res.json(json);
    } catch {
        res.send(data);
    }
  } catch (err) {
    res.status(500).json({ error: 'Erro ao ler arquivo' });
  }
});

// 3. Save Employees (Com Backup)
app.post('/api/save', (req, res) => {
  const filePath = path.resolve(dataDir, 'employees.json');
  
  // Backup Automático
  try {
    if (fs.existsSync(filePath)) {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupPath = path.resolve(backupDir, `employees-${timestamp}.json`);
      fs.copyFileSync(filePath, backupPath);

      // Limpeza de backups antigos (>50)
      const files = fs.readdirSync(backupDir);
      const backupFiles = files.filter(f => f.startsWith('employees-') && f.endsWith('.json'));
      if (backupFiles.length > 50) {
        backupFiles.sort();
        const filesToDelete = backupFiles.slice(0, backupFiles.length - 50);
        filesToDelete.forEach(file => {
          fs.unlinkSync(path.resolve(backupDir, file));
        });
      }
    }
  } catch (backupErr) {
    console.error('Erro ao criar backup automático:', backupErr);
  }

  // Salvar novo arquivo
  // Express com express.text() coloca o corpo em req.body se for text/plain ou application/json
  // Se os dados vierem como string criptografada pura:
  let content = req.body;
  
  // Se for objeto (express parseou JSON), converte de volta para string se necessário,
  // mas nosso frontend envia string crua criptografada geralmente.
  if (typeof content === 'object') {
      content = JSON.stringify(content);
  }

  try {
    fs.writeFileSync(filePath, content);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao salvar arquivo' });
  }
});

// 4. Admin Load
app.get('/api/admin/load', (req, res) => {
    const filePath = path.resolve(dataDir, 'admin.json');
    if (!fs.existsSync(filePath)) {
        return res.json({ password: null });
    }
    try {
        const data = fs.readFileSync(filePath, 'utf-8');
        res.send(data); // Envia como texto raw
    } catch (err) {
        res.json({ password: null });
    }
});

// 5. Admin Save
app.post('/api/admin/save', (req, res) => {
    const filePath = path.resolve(dataDir, 'admin.json');
    let content = req.body;
    if (typeof content === 'object') content = JSON.stringify(content);

    try {
        fs.writeFileSync(filePath, content);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: 'Erro ao salvar admin' });
    }
});

// --- SERVIR ARQUIVOS ESTÁTICOS (Frontend React) ---
// Serve a pasta 'dist' que é criada pelo comando 'npm run build'
app.use(express.static(path.join(__dirname, 'dist')));

// Qualquer outra rota retorna o index.html (para o React Router funcionar)
app.get('*', (req, res) => {
  const indexPath = path.resolve(__dirname, 'dist', 'index.html');
  if (fs.existsSync(indexPath)) {
      res.sendFile(indexPath);
  } else {
      res.send('O sistema precisa ser compilado. Rode "npm run build" primeiro.');
  }
});

// Inicia o servidor acessível na rede (0.0.0.0)
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n==================================================`);
  console.log(` SERVIDOR GESTÃO RH INICIADO`);
  console.log(`==================================================`);
  console.log(`Local:           http://localhost:${PORT}`);
  console.log(`Na sua Rede:     http://SEU_IP_DO_PC:${PORT}`);
  console.log(`Pasta de Dados:  ${dataDir}`);
  console.log(`\nPara parar, pressione CTRL + C`);
});