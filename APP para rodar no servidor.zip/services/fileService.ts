import { Employee } from '../types';
import { encryptData, decryptData } from '../utils/crypto';

// Browser native types for File System Access API
interface FileSystemHandle {
  kind: 'file' | 'directory';
  name: string;
  isSameEntry(other: FileSystemHandle): Promise<boolean>;
}

interface FileSystemDirectoryHandle extends FileSystemHandle {
  getFileHandle(name: string, options?: { create?: boolean }): Promise<FileSystemFileHandle>;
  requestPermission(descriptor: { mode: 'read' | 'readwrite' }): Promise<'granted' | 'denied' | 'prompt'>;
  queryPermission(descriptor: { mode: 'read' | 'readwrite' }): Promise<'granted' | 'denied' | 'prompt'>;
}

interface FileSystemFileHandle extends FileSystemHandle {
  createWritable(): Promise<FileSystemWritableFileStream>;
  getFile(): Promise<File>;
}

interface FileSystemWritableFileStream extends WritableStream {
  write(data: string): Promise<void>;
  close(): Promise<void>;
}

declare global {
  interface Window {
    showDirectoryPicker(): Promise<FileSystemDirectoryHandle>;
    showSaveFilePicker(options?: any): Promise<FileSystemFileHandle>;
    showOpenFilePicker(options?: any): Promise<FileSystemFileHandle[]>;
  }
}

const DB_FILENAME = 'employees.json';
const ADMIN_FILENAME = 'admin.json';
const LOCAL_STORAGE_KEY = 'rh_employees_backup';
const LOCAL_STORAGE_ADMIN_KEY = 'rh_admin_password';
const IDB_NAME = 'GestaoRH_DB';
const IDB_STORE = 'handles';

export class FileService {
  private directoryHandle: FileSystemDirectoryHandle | null = null;
  private useLocalStorage: boolean = false;
  private useLocalApi: boolean = false; // New flag for server-side mode

  // --- Initialize / Check Mode ---
  
  public async checkLocalServer(): Promise<boolean> {
    try {
        const response = await fetch('/api/status');
        if (response.ok) {
            const data = await response.json();
            if (data.status === 'ok') {
                this.useLocalApi = true;
                return true;
            }
        }
    } catch (e) {
        // Local server API not available, proceed to standard browser modes
    }
    return false;
  }

  // --- IndexedDB Helpers ---

  private async getDB(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(IDB_NAME, 1);
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);
      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        db.createObjectStore(IDB_STORE);
      };
    });
  }

  private async saveHandleToDB(handle: FileSystemDirectoryHandle): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(IDB_STORE, 'readwrite');
      const store = transaction.objectStore(IDB_STORE);
      const request = store.put(handle, 'rootDirectory');
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  private async getHandleFromDB(): Promise<FileSystemDirectoryHandle | undefined> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(IDB_STORE, 'readonly');
      const store = transaction.objectStore(IDB_STORE);
      const request = store.get('rootDirectory');
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => resolve(undefined); // Fail silently
    });
  }

  // --- Main Methods ---

  public async verifyPermission(handle: FileSystemDirectoryHandle, readWrite: boolean): Promise<boolean> {
    const options = { mode: readWrite ? 'readwrite' : 'read' as 'read' | 'readwrite' };
    
    // Check if permission was already granted
    if ((await handle.queryPermission(options)) === 'granted') {
      return true;
    }
    
    // Request permission
    if ((await handle.requestPermission(options)) === 'granted') {
      return true;
    }
    
    return false;
  }

  public async restoreSession(): Promise<string | null> {
    // 1. Try Local API First (Automatic Mode)
    const isLocal = await this.checkLocalServer();
    if (isLocal) {
        return "Pasta Local (./Data)";
    }

    // 2. Try IndexedDB Handle (Browser Memory Mode)
    try {
      const handle = await this.getHandleFromDB();
      if (handle) {
        this.directoryHandle = handle;
        return handle.name;
      }
    } catch (e) {
      console.warn('Error restoring session:', e);
    }
    return null;
  }

  public async reconnectDirectory(): Promise<string> {
    if (this.useLocalApi) return "Pasta Local (./Data)";

    if (!this.directoryHandle) throw new Error("Nenhum diretório salvo encontrado.");
    
    const hasPermission = await this.verifyPermission(this.directoryHandle, true);
    if (!hasPermission) {
      this.directoryHandle = null;
      throw new Error("Permissão negada.");
    }
    
    return this.directoryHandle.name;
  }

  public async selectDirectory(): Promise<string> {
    // Force check local API first if user manually clicked "Select Folder" but server is available
    if (await this.checkLocalServer()) {
        return "Pasta Local (./Data)";
    }

    this.directoryHandle = null;
    this.useLocalStorage = false;
    this.useLocalApi = false;

    if (!('showDirectoryPicker' in window)) {
      console.warn('File System Access API not supported. Falling back to LocalStorage.');
      this.useLocalStorage = true;
      return 'Armazenamento Local (Navegador)';
    }
    
    try {
      this.directoryHandle = await window.showDirectoryPicker();
      
      // Save handle for future use
      await this.saveHandleToDB(this.directoryHandle);

      return this.directoryHandle.name;
    } catch (err: any) {
      const isSecurityError = err.name === 'SecurityError' || 
                             (err.message && typeof err.message === 'string' && err.message.includes('Cross origin sub frames'));

      if (isSecurityError) {
         console.warn('File System Access API blocked in iframe. Falling back to LocalStorage.');
         this.useLocalStorage = true;
         return 'Modo Demo (Permissão Bloqueada)';
      }
      
      if (err.name === 'AbortError') {
         throw new Error('Seleção de pasta cancelada.');
      }

      console.error(err);
      throw new Error('Falha ao acessar sistema de arquivos.');
    }
  }

  public hasHandle(): boolean {
    return this.directoryHandle !== null || this.useLocalStorage || this.useLocalApi;
  }

  public getDirectoryName(): string | null {
    if (this.useLocalApi) return 'Pasta Local (./Data)';
    if (this.useLocalStorage) return 'Armazenamento Local';
    return this.directoryHandle ? this.directoryHandle.name : null;
  }

  // --- Employee Data Methods ---

  public async loadEmployees(): Promise<Employee[]> {
    // 1. Local API Mode
    if (this.useLocalApi) {
        try {
            const response = await fetch('/api/load');
            const text = await response.text();
            if (!text || text === '[]') return [];
            
            if (text.startsWith('ENC:')) {
                return await decryptData(text);
            }
            return JSON.parse(text);
        } catch (e) {
            console.error('API Load Error:', e);
            throw new Error('Falha ao carregar da pasta Data.');
        }
    }

    // 2. Local Storage Mode
    if (this.useLocalStorage) {
        const data = localStorage.getItem(LOCAL_STORAGE_KEY);
        if (!data) return [];
        if (data.startsWith('ENC:')) {
           return await decryptData(data);
        }
        try {
           return JSON.parse(data);
        } catch { return []; }
    }

    // 3. File System API Mode
    if (!this.directoryHandle) throw new Error('Nenhuma pasta selecionada.');

    try {
      const fileHandle = await this.directoryHandle.getFileHandle(DB_FILENAME, { create: true });
      const file = await fileHandle.getFile();
      const text = await file.text();
      
      if (!text) return []; 
      
      if (text.startsWith('ENC:')) {
        return await decryptData(text);
      } else {
        try {
          return JSON.parse(text) as Employee[];
        } catch (e) {
          console.error("File is not valid JSON or Encrypted data");
          return [];
        }
      }
    } catch (error) {
      console.warn('Could not load file, maybe it is new:', error);
      return [];
    }
  }

  public async saveEmployees(employees: Employee[]): Promise<void> {
    const encryptedContent = await encryptData(employees);

    // 1. Local API Mode
    if (this.useLocalApi) {
        try {
            const response = await fetch('/api/save', {
                method: 'POST',
                body: encryptedContent
            });
            if (!response.ok) throw new Error('Server returned error');
            return;
        } catch (e) {
            console.error('API Save Error', e);
            throw new Error('Falha ao salvar na pasta Data.');
        }
    }

    // 2. Local Storage Mode
    if (this.useLocalStorage) {
        localStorage.setItem(LOCAL_STORAGE_KEY, encryptedContent);
        return;
    }

    // 3. File System API Mode
    if (!this.directoryHandle) throw new Error('Nenhuma pasta selecionada.');

    try {
      const fileHandle = await this.directoryHandle.getFileHandle(DB_FILENAME, { create: true });
      const writable = await fileHandle.createWritable();
      await writable.write(encryptedContent);
      await writable.close();
    } catch (error) {
      console.error('Error saving file:', error);
      throw new Error('Falha ao salvar o arquivo no disco.');
    }
  }

  // --- Admin Password Methods ---

  public async saveAdminPassword(password: string): Promise<void> {
    const encryptedPass = await encryptData({ password });

    if (this.useLocalApi) {
        await fetch('/api/admin/save', { method: 'POST', body: encryptedPass });
        return;
    }

    if (this.useLocalStorage) {
        localStorage.setItem(LOCAL_STORAGE_ADMIN_KEY, encryptedPass);
        return;
    }

    if (this.directoryHandle) {
        const fileHandle = await this.directoryHandle.getFileHandle(ADMIN_FILENAME, { create: true });
        const writable = await fileHandle.createWritable();
        await writable.write(encryptedPass);
        await writable.close();
    }
  }

  public async loadAdminPassword(): Promise<string | null> {
    let content = '';

    if (this.useLocalApi) {
        try {
            const res = await fetch('/api/admin/load');
            // FIX: Don't use res.json() because the file content might be "ENC:..." string
            // which causes a syntax error in JSON.parse().
            const text = await res.text();
            
            // The server returns JSON ONLY if the file is missing/null
            if (text.includes('"password":null') || text.includes('"password": null')) {
                return null;
            }
            
            content = text;
        } catch { return null; }
    } else if (this.useLocalStorage) {
        const data = localStorage.getItem(LOCAL_STORAGE_ADMIN_KEY);
        if (!data) return null;
        content = data;
    } else if (this.directoryHandle) {
        try {
            const fileHandle = await this.directoryHandle.getFileHandle(ADMIN_FILENAME);
            const file = await fileHandle.getFile();
            content = await file.text();
        } catch { return null; }
    }

    if (!content) return null;

    try {
        if (content.startsWith('ENC:')) {
            const data = await decryptData(content);
            return data.password;
        }
        // Legacy or raw check
        const parsed = JSON.parse(content);
        return parsed.password || null;
    } catch (e) {
        return null;
    }
  }

  // --- Manual Backup Utilities ---

  public async exportBackup(employees: Employee[]): Promise<void> {
    const encryptedContent = await encryptData(employees);
    
    if ('showSaveFilePicker' in window) {
      try {
        const dateStr = new Date().toISOString().split('T')[0];
        const fileHandle = await window.showSaveFilePicker({
          suggestedName: `backup_rh_${dateStr}.rhbk`,
          types: [{
            description: 'Backup RH Encrypted',
            accept: { 'application/octet-stream': ['.rhbk'] },
          }],
        });
        const writable = await fileHandle.createWritable();
        await writable.write(encryptedContent);
        await writable.close();
      } catch (err: any) {
        if (err.name !== 'AbortError') throw err;
      }
    } else {
      const blob = new Blob([encryptedContent], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup_rh_${new Date().toISOString().split('T')[0]}.rhbk`;
      a.click();
      URL.revokeObjectURL(url);
    }
  }

  public async importBackup(): Promise<Employee[]> {
    let text = '';
    
    if ('showOpenFilePicker' in window) {
      try {
        const [fileHandle] = await window.showOpenFilePicker({
          types: [{
            description: 'Backup RH Encrypted',
            accept: { 'application/octet-stream': ['.rhbk', '.json'] },
          }],
        });
        const file = await fileHandle.getFile();
        text = await file.text();
      } catch (err: any) {
        if (err.name === 'AbortError') throw new Error('Seleção cancelada.');
        throw err;
      }
    } else {
       throw new Error('Navegador não suporta seletor de arquivo nativo.');
    }

    if (!text) throw new Error('Arquivo vazio.');

    if (text.startsWith('ENC:')) {
      return await decryptData(text);
    } else {
      return JSON.parse(text);
    }
  }
  
  public async processBackupFile(file: File): Promise<Employee[]> {
    const text = await file.text();
    if (text.startsWith('ENC:')) {
      return await decryptData(text);
    }
    return JSON.parse(text);
  }
}

export const fileService = new FileService();