import React, { useState } from 'react';
import { Employee, UserRole } from '../types';
import { Button } from './Button';
import { Input } from './Input';
import { fileService } from '../services/fileService';

interface LoginPageProps {
  employees: Employee[];
  onLogin: (user: Employee | 'super-admin') => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ employees, onLogin }) => {
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Check for Admin (Stored or Hardcoded)
      if (login === 'admin') {
         const storedAdminPass = await fileService.loadAdminPassword();
         const validPass = storedAdminPass || 'RHSERVICE141629042205';

         if (password === validPass) {
           onLogin('super-admin');
           return;
         }
      }

      // Check for Employees
      const user = employees.find(emp => emp.registrationNumber === login);

      if (!user) {
        // If it was an admin attempt that failed password, it falls here too if user not found,
        // but let's be specific if login was 'admin'
        if (login === 'admin') {
           setError('Senha de administrador incorreta.');
        } else {
           setError('Usuário não encontrado.');
        }
        setLoading(false);
        return;
      }

      // Default password logic check (GCMVV + CurrentYear) if password field is missing
      const currentYear = new Date().getFullYear();
      const defaultPassword = `GCMVV${currentYear}`;
      const userPass = user.password || defaultPassword;

      if (password === userPass) {
        onLogin(user);
      } else {
        setError('Senha incorreta.');
      }
    } catch (err) {
      console.error(err);
      setError('Erro ao processar login.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100 p-4">
      <div className="max-w-md w-full bg-white rounded-xl shadow-lg p-8 border border-slate-200">
        <div className="text-center mb-8">
          {/* Logo Section */}
          <div className="flex justify-center mb-6">
             <img 
               src="logo.png" 
               alt="Brasão Guarda Municipal" 
               className="h-32 w-auto object-contain drop-shadow-sm transition-transform hover:scale-105 duration-300"
               onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  const parent = e.currentTarget.parentElement;
                  if (parent) {
                    const fallback = document.createElement('div');
                    fallback.innerHTML = '<span class="text-4xl">🛡️</span>';
                    parent.appendChild(fallback);
                  }
               }}
             />
          </div>
          
          <h2 className="text-2xl font-bold text-slate-800">Acesso ao Sistema</h2>
          <p className="text-slate-500 text-sm mt-1">Gestão de RH Local</p>
        </div>

        <form onSubmit={handleLogin}>
          <Input
            label="Matrícula (Login)"
            value={login}
            onChange={(e) => setLogin(e.target.value)}
            placeholder="Digite sua matrícula ou 'admin'"
            autoFocus
            disabled={loading}
          />
          
          <Input
            label="Senha"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Digite sua senha"
            disabled={loading}
          />

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-100 rounded text-red-600 text-sm flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {error}
            </div>
          )}

          <Button type="submit" className="w-full py-3 text-lg mt-2" disabled={loading}>
            {loading ? 'Entrando...' : 'Entrar'}
          </Button>
        </form>

        <div className="mt-8 text-center text-xs text-slate-400">
          <p>Senha Padrão: GCMVV + Ano Atual (Ex: GCMVV2025)</p>
          <p className="mt-1">Login Admin Inicial: admin / RHSERVICE141629042205</p>
        </div>
      </div>
    </div>
  );
};