import React, { useState, useEffect, useRef } from 'react';
import { Employee } from '../types';

interface EmployeeSelectProps {
  employees: Employee[];
  value: string; // The selected Employee ID
  onChange: (value: string) => void;
  disabled?: boolean;
}

export const EmployeeSelect: React.FC<EmployeeSelectProps> = ({ employees, value, onChange, disabled }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const wrapperRef = useRef<HTMLDivElement>(null);

  // Sync internal search term with external value (ID) changes
  useEffect(() => {
    if (value) {
      const selected = employees.find(e => e.id === value);
      if (selected) {
        setSearchTerm(`${selected.name} (Mat: ${selected.registrationNumber})`);
      }
    } else {
      setSearchTerm('');
    }
  }, [value, employees]);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        // Optional: If the user typed something but didn't select, we could either clear it or keep it.
        // Current behavior: It stays as text, but the ID remains empty (set via handleInputChange) until a valid selection is made.
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const filteredEmployees = employees.filter(emp => {
    const term = searchTerm.toLowerCase();
    return (
      emp.name.toLowerCase().includes(term) ||
      emp.registrationNumber.toLowerCase().includes(term)
    );
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setIsOpen(true);
    // Important: Clear the selected ID when the user modifies the text manually
    // This forces them to select a valid option from the list
    if (value) {
        onChange('');
    }
  };

  const handleSelect = (emp: Employee) => {
    onChange(emp.id);
    setSearchTerm(`${emp.name} (Mat: ${emp.registrationNumber})`);
    setIsOpen(false);
  };

  return (
    <div className="mb-6 relative" ref={wrapperRef}>
      <label className="block text-sm font-medium text-slate-700 mb-1">
        Selecione o Funcionário
      </label>
      <div className="relative">
        <input
          type="text"
          className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 bg-white disabled:bg-slate-100 disabled:text-slate-500 ${
             !value && searchTerm && !isOpen ? 'border-red-300 focus:ring-red-200' : 'border-slate-300'
          }`}
          placeholder="Busque por nome ou matrícula..."
          value={searchTerm}
          onChange={handleInputChange}
          onFocus={() => setIsOpen(true)}
          disabled={disabled}
        />
        {/* Chevron Icon */}
        <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none text-slate-400">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
          </svg>
        </div>
      </div>

      {isOpen && !disabled && (
        <div className="absolute z-50 w-full mt-1 bg-white border border-slate-200 rounded-md shadow-lg max-h-60 overflow-auto">
          {filteredEmployees.length === 0 ? (
            <div className="px-4 py-3 text-sm text-slate-500 text-center">
              Nenhum funcionário encontrado.
            </div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {filteredEmployees.map((emp) => (
                <li
                  key={emp.id}
                  className="px-4 py-2 hover:bg-brand-50 cursor-pointer transition-colors"
                  onClick={() => handleSelect(emp)}
                >
                  <div className="font-medium text-slate-800 text-sm">{emp.name}</div>
                  <div className="text-xs text-slate-500">Matrícula: {emp.registrationNumber}</div>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
};