import React from 'react';
import { Attachment } from '../types';
import { Button } from './Button';

interface FileViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  attachment: Attachment | null;
}

export const FileViewerModal: React.FC<FileViewerModalProps> = ({ isOpen, onClose, attachment }) => {
  if (!isOpen || !attachment) return null;

  const isImage = attachment.mimeType.startsWith('image/');
  const isPdf = attachment.mimeType === 'application/pdf';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75 p-4 animate-fade-in">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-4xl h-[90vh] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="flex justify-between items-center px-6 py-4 border-b border-slate-200 bg-slate-50">
          <h3 className="text-lg font-bold text-slate-800 truncate flex-1 pr-4" title={attachment.name}>
            Visualizando: {attachment.name}
          </h3>
          <div className="flex gap-2">
             <a 
               href={attachment.data} 
               download={attachment.name}
               className="px-4 py-2 bg-brand-600 text-white rounded-md text-sm font-medium hover:bg-brand-700 flex items-center gap-2 transition-colors"
             >
               <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
               </svg>
               Baixar
             </a>
             <button 
               onClick={onClose}
               className="p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-200 rounded-md transition-colors"
             >
               <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
               </svg>
             </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 bg-slate-100 overflow-auto flex items-center justify-center p-4 relative">
          {isImage ? (
            <img 
              src={attachment.data} 
              alt={attachment.name} 
              className="max-w-full max-h-full object-contain shadow-lg" 
            />
          ) : isPdf ? (
            <iframe 
              src={attachment.data} 
              title={attachment.name}
              className="w-full h-full border-none shadow-sm bg-white"
            />
          ) : (
            <div className="text-center p-8 bg-white rounded-lg shadow-sm">
              <svg className="w-16 h-16 text-slate-300 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <p className="text-slate-600 mb-2">Pré-visualização não disponível para este formato.</p>
              <p className="text-sm text-slate-400">Utilize o botão "Baixar" acima.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};