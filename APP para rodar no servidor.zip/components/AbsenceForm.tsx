import React, { useState } from 'react';
import { Employee } from '../types';
import { Input } from './Input';
import { Button } from './Button';

interface AbsenceFormProps {
  employees: Employee[];
  onSave: (employeeId: string, date: string, reason: string) => void;
  disabled?: boolean;
}

export const AbsenceForm: React.FC<AbsenceFormProps> = ({ employees, onSave, disabled }) => {
  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [date, setDate] = useState('');
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEmployeeId) {
      setError('Selecione um funcionário.');
      return;
    }
    if (!date) {
      setError('Selecione a data da falta.');
      return;
    }
    if (!reason.trim()) {
      setError('Informe o motivo/observação.');
      return;
    }

    onSave(selectedEmployeeId, date, reason);
    
    // Reset fields except employee to allow rapid entry
    setDate('');
    setReason('');
    setError('');
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
      <div className="mb-6">
        <label className="block text-sm font-medium text-slate-700 mb-1">
          Selecione o Funcionário
        </label>
        <select
          className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 bg-white"
          value={selectedEmployeeId}
          onChange={(e) => setSelectedEmployeeId(e.target.value)}
          disabled={disabled}
        >
          <option value="">-- Selecione --</option>
          {employees.map((emp) => (
            <option key={emp.id} value={emp.id}>
              {emp.name} (Mat: {emp.registrationNumber})
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Data da Falta"
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          disabled={disabled}
        />

        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Observação / Motivo
          </label>
          <textarea
            className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 min-h-[100px]"
            placeholder="Descreva o motivo da falta..."
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            disabled={disabled}
          />
        </div>
      </div>

      {error && <p className="mt-4 text-sm text-red-600">{error}</p>}

      <div className="mt-6 flex justify-end">
        <Button type="submit" disabled={disabled} variant="danger">
          Confirmar e Lançar Falta
        </Button>
      </div>
      
      <p className="mt-4 text-xs text-slate-400 text-right">
        * Ao lançar a falta, um dia trabalhado será descontado automaticamente do mês correspondente.
      </p>
    </form>
  );
};