import React, { useState } from 'react';
import { Employee } from '../types';
import { Input } from './Input';
import { Button } from './Button';
import { EmployeeSelect } from './EmployeeSelect';

interface BankHourFormProps {
  employees: Employee[];
  onSave: (employeeId: string, date: string, hours: number, minutes: number, reason: string) => void;
  disabled?: boolean;
}

export const BankHourForm: React.FC<BankHourFormProps> = ({ employees, onSave, disabled }) => {
  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [date, setDate] = useState('');
  const [hours, setHours] = useState('');
  const [minutes, setMinutes] = useState('');
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!selectedEmployeeId) {
      setError('Selecione um funcionário.');
      return;
    }
    if (!date) {
      setError('Selecione a data.');
      return;
    }
    if (!hours && !minutes) {
      setError('Informe a quantidade de horas ou minutos.');
      return;
    }
    
    // Validation for reason removed (Optional)

    const h = parseInt(hours || '0', 10);
    const m = parseInt(minutes || '0', 10);

    if (h < 0 || m < 0) {
       setError('Valores não podem ser negativos.');
       return;
    }
    
    if (h === 0 && m === 0) {
       setError('O tempo total não pode ser zero.');
       return;
    }

    onSave(selectedEmployeeId, date, h, m, reason);

    // Reset non-fixed fields
    setHours('');
    setMinutes('');
    setReason('');
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
      <EmployeeSelect
        employees={employees}
        value={selectedEmployeeId}
        onChange={setSelectedEmployeeId}
        disabled={disabled}
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Input
          label="Data"
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          disabled={disabled}
        />
        <Input
          label="Horas"
          type="number"
          min="0"
          value={hours}
          onChange={(e) => setHours(e.target.value)}
          placeholder="Ex: 2"
          disabled={disabled}
        />
        <Input
          label="Minutos"
          type="number"
          min="0"
          max="59"
          value={minutes}
          onChange={(e) => setMinutes(e.target.value)}
          placeholder="Ex: 30"
          disabled={disabled}
        />
      </div>

      <div className="mt-4">
        <label className="block text-sm font-medium text-slate-700 mb-1">
          Observação (Opcional)
        </label>
        <textarea
          className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 min-h-[100px]"
          placeholder="Descreva o motivo (ex: Hora extra, trabalho no feriado...)"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          disabled={disabled}
        />
      </div>

      {error && (
        <div className="mt-4 p-3 bg-red-50 text-red-700 text-sm rounded border border-red-200">
          {error}
        </div>
      )}

      <div className="mt-6 flex justify-between items-center">
         <div className="text-xs text-slate-500 max-w-sm">
             * Este lançamento será somado ao saldo total do Banco de Horas.
         </div>
        <Button type="submit" disabled={disabled} variant="primary">
          Lançar Banco de Horas
        </Button>
      </div>
    </form>
  );
};