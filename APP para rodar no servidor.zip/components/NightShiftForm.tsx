import React, { useState } from 'react';
import { Employee } from '../types';
import { Input } from './Input';
import { Button } from './Button';
import { EmployeeSelect } from './EmployeeSelect';

interface NightShiftFormProps {
  employees: Employee[];
  onSave: (employeeId: string, month: string, hours: number) => void;
  disabled?: boolean;
}

export const NightShiftForm: React.FC<NightShiftFormProps> = ({ employees, onSave, disabled }) => {
  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [month, setMonth] = useState('');
  const [hours, setHours] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!selectedEmployeeId) {
      setError('Selecione um funcionário.');
      return;
    }
    if (!month) {
      setError('Selecione o mês de referência.');
      return;
    }
    if (!hours) {
      setError('Informe a quantidade de horas.');
      return;
    }

    const hoursNum = parseFloat(hours);

    if (hoursNum < 0) {
       setError('A quantidade de horas não pode ser negativa.');
       return;
    }
    
    if (hoursNum === 0) {
       setError('A quantidade de horas deve ser maior que zero.');
       return;
    }

    onSave(selectedEmployeeId, month, hoursNum);

    // Reset non-fixed fields
    setHours('');
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
      <EmployeeSelect
        employees={employees}
        value={selectedEmployeeId}
        onChange={setSelectedEmployeeId}
        disabled={disabled}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Mês de Referência"
          type="month"
          value={month}
          onChange={(e) => setMonth(e.target.value)}
          disabled={disabled}
        />
        <Input
          label="Quantidade de Horas"
          type="number"
          min="0"
          step="0.5"
          value={hours}
          onChange={(e) => setHours(e.target.value)}
          placeholder="Ex: 10"
          disabled={disabled}
        />
      </div>

      {error && (
        <div className="mt-4 p-3 bg-red-50 text-red-700 text-sm rounded border border-red-200">
          {error}
        </div>
      )}

      <div className="mt-6 flex justify-between items-center">
         <div className="text-xs text-slate-500 max-w-sm">
             * Registra horas de adicional noturno para processamento da folha.
         </div>
        <Button type="submit" disabled={disabled} variant="primary">
          Lançar Adicional Noturno
        </Button>
      </div>
    </form>
  );
};