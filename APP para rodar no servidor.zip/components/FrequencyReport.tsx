import React, { useState, useMemo } from 'react';
import { Employee } from '../types';
import { Button } from './Button';

interface FrequencyReportProps {
  employees: Employee[];
}

// Helper to get total days in a month
const getDaysInMonth = (yearMonth: string) => {
  const [year, month] = yearMonth.split('-').map(Number);
  return new Date(year, month, 0).getDate();
};

export const FrequencyReport: React.FC<FrequencyReportProps> = ({ employees }) => {
  // Default to current month YYYY-MM
  const getCurrentMonth = () => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  };

  const [selectedMonth, setSelectedMonth] = useState(getCurrentMonth());
  
  // Column Selection State
  const [visibleColumns, setVisibleColumns] = useState({
    registrationNumber: true,
    daysWorked: true,
    specialSchedule: true,
    absences: true,
    vacations: true,
    abonos: true,
    medicalCertificates: true,
  });

  const toggleColumn = (key: keyof typeof visibleColumns) => {
    setVisibleColumns(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const reportData = useMemo(() => {
    const totalDaysInMonth = getDaysInMonth(selectedMonth);

    return employees.map(emp => {
      // Filter records for the selected month
      const monthlyAlterations = (emp.alterationHistory || []).filter(record => 
        record.date.startsWith(selectedMonth)
      );

      const monthlySchedules = (emp.specialScheduleHistory || []).filter(record => 
        record.date.startsWith(selectedMonth)
      );

      let absencesCount = 0;
      let vacationDays = 0;
      let abonosCount = 0;
      let medicalCertificatesCount = 0;
      let daysToDeduct = 0;

      monthlyAlterations.forEach(record => {
        if (record.type === 'Falta') {
          absencesCount++;
          daysToDeduct++;
        } else if (record.type === 'Férias') {
          vacationDays++;
          daysToDeduct++;
        } else if (record.type === 'Atestado Médico') {
          medicalCertificatesCount++;
          daysToDeduct++;
        } else if (record.type === 'Abono') {
          abonosCount++;
          if (record.abonoType === 'Doação de Sangue' || record.abonoType === 'TRE') {
            daysToDeduct++;
          }
        }
      });

      const daysWorked = Math.max(0, totalDaysInMonth - daysToDeduct);
      const specialScheduleCount = monthlySchedules.length; // Counting number of shifts, could also be cost

      return {
        id: emp.id,
        name: emp.name,
        registrationNumber: emp.registrationNumber,
        daysWorked,
        specialScheduleCount,
        absencesCount,
        vacationDays,
        abonosCount,
        medicalCertificatesCount
      };
    });
  }, [employees, selectedMonth]);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
      
      {/* Controls - Hidden when printing */}
      <div className="mb-6 print:hidden">
        <h2 className="text-2xl font-bold text-slate-800 mb-4">Relatório de Frequência</h2>
        
        <div className="flex flex-wrap items-end gap-4 bg-slate-50 p-4 rounded-lg border border-slate-100 mb-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Mês de Referência</label>
            <input
              type="month"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>

          <Button onClick={handlePrint} className="flex items-center gap-2">
             <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
             </svg>
             Imprimir / Salvar PDF
          </Button>
        </div>

        <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
           <span className="text-sm font-bold text-slate-700 block mb-2">Colunas Visíveis:</span>
           <div className="flex flex-wrap gap-4">
             <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
               <input type="checkbox" checked={visibleColumns.registrationNumber} onChange={() => toggleColumn('registrationNumber')} className="rounded text-brand-600 focus:ring-brand-500" />
               Matrícula
             </label>
             <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
               <input type="checkbox" checked={visibleColumns.daysWorked} onChange={() => toggleColumn('daysWorked')} className="rounded text-brand-600 focus:ring-brand-500" />
               Dias Trabalhados
             </label>
             <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
               <input type="checkbox" checked={visibleColumns.specialSchedule} onChange={() => toggleColumn('specialSchedule')} className="rounded text-brand-600 focus:ring-brand-500" />
               Escala Especial
             </label>
             <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
               <input type="checkbox" checked={visibleColumns.absences} onChange={() => toggleColumn('absences')} className="rounded text-brand-600 focus:ring-brand-500" />
               Faltas
             </label>
             <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
               <input type="checkbox" checked={visibleColumns.vacations} onChange={() => toggleColumn('vacations')} className="rounded text-brand-600 focus:ring-brand-500" />
               Férias
             </label>
             <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
               <input type="checkbox" checked={visibleColumns.abonos} onChange={() => toggleColumn('abonos')} className="rounded text-brand-600 focus:ring-brand-500" />
               Abonos
             </label>
             <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
               <input type="checkbox" checked={visibleColumns.medicalCertificates} onChange={() => toggleColumn('medicalCertificates')} className="rounded text-brand-600 focus:ring-brand-500" />
               Atestados
             </label>
           </div>
        </div>
      </div>

      {/* Print Header */}
      <div className="hidden print:block mb-8 text-center">
         <h1 className="text-2xl font-bold uppercase border-b-2 border-black pb-2">Relatório de Frequência Mensal</h1>
         <p className="mt-2 text-lg">Mês de Referência: <span className="font-bold">{new Date(selectedMonth + '-02').toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}</span></p>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-slate-200 border border-slate-200 print:border-black">
          <thead className="bg-slate-50 print:bg-slate-100">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider print:text-black print:border print:border-black">Nome</th>
              {visibleColumns.registrationNumber && <th className="px-4 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider print:text-black print:border print:border-black">Matrícula</th>}
              {visibleColumns.daysWorked && <th className="px-4 py-3 text-center text-xs font-bold text-slate-500 uppercase tracking-wider print:text-black print:border print:border-black">Dias Trab.</th>}
              {visibleColumns.specialSchedule && <th className="px-4 py-3 text-center text-xs font-bold text-slate-500 uppercase tracking-wider print:text-black print:border print:border-black">Escalas Esp.</th>}
              {visibleColumns.absences && <th className="px-4 py-3 text-center text-xs font-bold text-red-600 uppercase tracking-wider print:text-black print:border print:border-black">Faltas</th>}
              {visibleColumns.vacations && <th className="px-4 py-3 text-center text-xs font-bold text-blue-600 uppercase tracking-wider print:text-black print:border print:border-black">Férias (Dias)</th>}
              {visibleColumns.abonos && <th className="px-4 py-3 text-center text-xs font-bold text-green-600 uppercase tracking-wider print:text-black print:border print:border-black">Abonos</th>}
              {visibleColumns.medicalCertificates && <th className="px-4 py-3 text-center text-xs font-bold text-orange-600 uppercase tracking-wider print:text-black print:border print:border-black">Atestados</th>}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-slate-200 print:divide-black">
            {reportData.map((data) => (
              <tr key={data.id} className="hover:bg-slate-50 print:hover:bg-transparent">
                <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-slate-900 print:border print:border-black">{data.name}</td>
                {visibleColumns.registrationNumber && <td className="px-4 py-2 whitespace-nowrap text-sm text-slate-700 print:border print:border-black">{data.registrationNumber}</td>}
                {visibleColumns.daysWorked && <td className="px-4 py-2 whitespace-nowrap text-sm text-center text-slate-700 print:border print:border-black">{data.daysWorked}</td>}
                {visibleColumns.specialSchedule && <td className="px-4 py-2 whitespace-nowrap text-sm text-center text-slate-700 print:border print:border-black">{data.specialScheduleCount}</td>}
                {visibleColumns.absences && <td className="px-4 py-2 whitespace-nowrap text-sm text-center text-slate-700 font-medium print:border print:border-black">{data.absencesCount}</td>}
                {visibleColumns.vacations && <td className="px-4 py-2 whitespace-nowrap text-sm text-center text-slate-700 print:border print:border-black">{data.vacationDays}</td>}
                {visibleColumns.abonos && <td className="px-4 py-2 whitespace-nowrap text-sm text-center text-slate-700 print:border print:border-black">{data.abonosCount}</td>}
                {visibleColumns.medicalCertificates && <td className="px-4 py-2 whitespace-nowrap text-sm text-center text-slate-700 print:border print:border-black">{data.medicalCertificatesCount}</td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="mt-4 text-xs text-slate-400 text-right print:block hidden">
         Relatório gerado em {new Date().toLocaleDateString('pt-BR')} às {new Date().toLocaleTimeString('pt-BR')}
      </div>
    </div>
  );
};