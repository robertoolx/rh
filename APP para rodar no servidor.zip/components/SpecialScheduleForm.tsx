import React, { useState } from 'react';
import { Employee } from '../types';
import { Input } from './Input';
import { Button } from './Button';
import { EmployeeSelect } from './EmployeeSelect';

interface SpecialScheduleFormProps {
  employees: Employee[];
  onSave: (employeeId: string, date: string, startTime: string, endTime: string, duration: 6 | 12, cost: 1 | 2) => void;
  disabled?: boolean;
}

export const SpecialScheduleForm: React.FC<SpecialScheduleFormProps> = ({ employees, onSave, disabled }) => {
  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [date, setDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [error, setError] = useState('');

  const calculateDuration = (start: string, end: string) => {
    if (!start || !end) return 0;
    
    const [startH, startM] = start.split(':').map(Number);
    const [endH, endM] = end.split(':').map(Number);

    let startTotalMinutes = startH * 60 + startM;
    let endTotalMinutes = endH * 60 + endM;

    // Handle overnight shifts (e.g. 22:00 to 04:00)
    if (endTotalMinutes < startTotalMinutes) {
      endTotalMinutes += 24 * 60;
    }

    const diffMinutes = endTotalMinutes - startTotalMinutes;
    return diffMinutes / 60; // Returns hours
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!selectedEmployeeId) {
      setError('Selecione um funcionário.');
      return;
    }
    if (!date) {
      setError('Selecione a data.');
      return;
    }
    if (!startTime || !endTime) {
      setError('Informe os horários de início e fim.');
      return;
    }

    const duration = calculateDuration(startTime, endTime);

    if (Math.abs(duration - 6) > 0.1 && Math.abs(duration - 12) > 0.1) {
      setError(`O intervalo deve ser de exatamente 6 ou 12 horas. Calculado: ${duration.toFixed(1)} horas.`);
      return;
    }

    const cleanDuration = Math.round(duration) as 6 | 12;
    const cost = cleanDuration === 12 ? 2 : 1;

    // Check quota for the selected employee and month
    const employee = employees.find(e => e.id === selectedEmployeeId);
    if (employee) {
      const monthKey = date.substring(0, 7); // YYYY-MM
      
      const currentMonthRecords = (employee.specialScheduleHistory || []).filter(r => 
        r.date.startsWith(monthKey)
      );

      const usedQuota = currentMonthRecords.reduce((acc, curr) => acc + curr.cost, 0);

      if (usedQuota + cost > 4) {
        setError(`Limite mensal excedido. O funcionário já usou ${usedQuota}/4 escalas neste mês. Esta escala custa ${cost}.`);
        return;
      }
    }

    onSave(selectedEmployeeId, date, startTime, endTime, cleanDuration, cost);

    // Clear non-fixed fields
    setStartTime('');
    setEndTime('');
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
      <EmployeeSelect
        employees={employees}
        value={selectedEmployeeId}
        onChange={setSelectedEmployeeId}
        disabled={disabled}
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Input
          label="Data"
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          disabled={disabled}
        />
        <Input
          label="Horário Início"
          type="time"
          value={startTime}
          onChange={(e) => setStartTime(e.target.value)}
          disabled={disabled}
        />
        <Input
          label="Horário Fim"
          type="time"
          value={endTime}
          onChange={(e) => setEndTime(e.target.value)}
          disabled={disabled}
        />
      </div>

      {error && (
        <div className="mt-4 p-3 bg-red-50 text-red-700 text-sm rounded border border-red-200">
          {error}
        </div>
      )}

      <div className="mt-6 flex justify-between items-center">
        <div className="text-xs text-slate-500 max-w-sm">
          <p>* Máximo de 4 escalas (6h) por mês.</p>
          <p>* Escalas de 12h contam como 2 escalas.</p>
        </div>
        <Button type="submit" disabled={disabled} variant="primary">
          Lançar Escala Especial
        </Button>
      </div>
    </form>
  );
};