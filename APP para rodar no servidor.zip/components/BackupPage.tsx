import React, { useRef, useState } from 'react';
import { Employee } from '../types';
import { fileService } from '../services/fileService';
import { Button } from './Button';
import { getSeedData } from '../utils/seedData';

interface BackupPageProps {
  employees: Employee[];
  onImportSuccess: (data: Employee[]) => void;
}

export const BackupPage: React.FC<BackupPageProps> = ({ employees, onImportSuccess }) => {
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExport = async () => {
    try {
      setStatus('Gerando backup criptografado...');
      await fileService.exportBackup(employees);
      setStatus('Backup salvo com sucesso!');
    } catch (err) {
      console.error(err);
      setError('Erro ao salvar backup.');
      setStatus('');
    } finally {
      setTimeout(() => setStatus(''), 3000);
    }
  };

  const handleImportClick = () => {
    // Try native picker first via service, if fails fallback to hidden input
    fileService.importBackup()
      .then(data => {
        if (window.confirm(`Deseja restaurar ${data.length} registros? Isso substituirá os dados atuais.`)) {
           onImportSuccess(data);
           setStatus('Dados restaurados com sucesso!');
        }
      })
      .catch((err) => {
        if (err.message.includes('Navegador não suporta') || err.message.includes('cancelada')) {
           // If native picker not supported or cancelled, usually do nothing or trigger input
           if (err.message.includes('Navegador não suporta')) {
               fileInputRef.current?.click();
           }
        } else {
           setError('Erro ao ler backup: ' + err.message);
        }
      });
  };

  const handleFileInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setStatus('Lendo arquivo...');
      const data = await fileService.processBackupFile(file);
      if (window.confirm(`Backup válido encontrado. Restaurar ${data.length} funcionários? ATENÇÃO: Os dados atuais serão substituídos.`)) {
        onImportSuccess(data);
        setStatus('Restauração concluída!');
      } else {
        setStatus('Restauração cancelada.');
      }
    } catch (err) {
      console.error(err);
      setError('Arquivo inválido ou senha incorreta.');
      setStatus('');
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleLoadSeedData = () => {
    if (employees.length > 0) {
      const confirm = window.confirm(
        'ATENÇÃO: Já existem funcionários cadastrados. Carregar a base inicial irá SUBSTITUIR todos os dados atuais.\n\nDeseja continuar?'
      );
      if (!confirm) return;
    }

    try {
      setStatus('Processando base de dados inicial...');
      const seedData = getSeedData();
      onImportSuccess(seedData);
      setStatus(`Base carregada com sucesso! ${seedData.length} funcionários importados.`);
    } catch (err) {
      console.error(err);
      setError('Erro ao carregar base inicial.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold text-slate-800 mb-6">Dados e Backup</h2>
      
      <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
        
        {/* Automatic Backup Info */}
        <div className="mb-8 p-4 bg-emerald-50 border border-emerald-100 rounded-lg">
           <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-200 rounded-full text-emerald-700">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-bold text-emerald-900">Backup Automático Ativo</h3>
                <p className="text-sm text-emerald-700">
                  O sistema salva automaticamente uma cópia dos dados toda vez que você faz uma alteração.
                  <br/>
                  Os arquivos ficam na pasta: <strong>./Data/Backups</strong>.
                </p>
              </div>
           </div>
        </div>

        {/* Seed Data Section */}
        <div className="mb-8 p-4 bg-brand-50 border border-brand-100 rounded-lg">
           <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-brand-200 rounded-full text-brand-700">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-bold text-brand-900">Carregar Base Inicial</h3>
                <p className="text-sm text-brand-700">Importar lista de funcionários pré-cadastrada (GCM).</p>
              </div>
           </div>
           <Button onClick={handleLoadSeedData} className="w-full sm:w-auto bg-brand-600 hover:bg-brand-700 text-white">
             Carregar Lista Padrão
           </Button>
        </div>

        <div className="border-t border-slate-100 pt-8 mb-8">
           <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-blue-100 rounded-full text-blue-600">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-medium text-slate-900">Exportar Backup Manual</h3>
                <p className="text-sm text-slate-500">Gera um arquivo <code>.rhbk</code> criptografado contendo todos os dados atuais.</p>
              </div>
           </div>
           <Button onClick={handleExport} className="w-full sm:w-auto">
             Gerar e Salvar Backup
           </Button>
        </div>

        <div className="border-t border-slate-100 pt-8">
           <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-orange-100 rounded-full text-orange-600">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-medium text-slate-900">Restaurar Backup</h3>
                <p className="text-sm text-slate-500">Carrega dados de um arquivo de backup anterior. <span className="text-red-600 font-bold">Isso substituirá todos os dados atuais.</span></p>
              </div>
           </div>
           
           <input 
             type="file" 
             ref={fileInputRef} 
             onChange={handleFileInputChange} 
             className="hidden" 
             accept=".rhbk,.json"
           />
           
           <Button onClick={handleImportClick} variant="secondary" className="w-full sm:w-auto text-orange-700 bg-orange-50 border-orange-200 hover:bg-orange-100">
             Selecionar Arquivo para Restaurar
           </Button>
        </div>
      </div>

      <div className="mt-8 bg-slate-50 p-4 rounded-lg border border-slate-200 text-sm text-slate-600">
         <h4 className="font-bold mb-2 flex items-center gap-2">
           <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
           </svg>
           Segurança dos Dados
         </h4>
         <p>
           Os arquivos salvos na pasta do sistema (`employees.json`) e os backups gerados manualmente são 
           <strong> criptografados</strong>. Eles só podem ser abertos e lidos através deste aplicativo. 
           Se você tentar abri-los em um editor de texto comum, verá apenas códigos ilegíveis.
         </p>
      </div>

      {status && (
        <div className="fixed bottom-4 right-4 bg-slate-800 text-white px-4 py-2 rounded shadow-lg animate-fade-in z-50">
          {status}
        </div>
      )}
      
      {error && (
        <div className="fixed bottom-4 right-4 bg-red-600 text-white px-4 py-2 rounded shadow-lg animate-fade-in z-50">
          {error}
        </div>
      )}
    </div>
  );
};