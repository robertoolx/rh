import React, { useState, useRef } from 'react';
import { Employee, AlterationType, AbonoType, Attachment } from '../types';
import { Input } from './Input';
import { Button } from './Button';
import { EmployeeSelect } from './EmployeeSelect';

interface AlterationFormProps {
  employees: Employee[];
  onSave: (
    employeeId: string, 
    date: string, 
    type: AlterationType, 
    abonoType: AbonoType | undefined, 
    reason: string,
    attachment: Attachment | undefined,
    endDate?: string,
    hours?: number,
    minutes?: number
  ) => void;
  disabled?: boolean;
}

export const AlterationForm: React.FC<AlterationFormProps> = ({ employees, onSave, disabled }) => {
  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [type, setType] = useState<AlterationType>('Falta');
  const [abonoType, setAbonoType] = useState<AbonoType>('Doação de Sangue');
  const [date, setDate] = useState(''); // Acts as Start Date for ranges
  const [endDate, setEndDate] = useState(''); // New State for End Date
  const [hours, setHours] = useState(''); // For Folga
  const [minutes, setMinutes] = useState(''); // For Folga
  const [reason, setReason] = useState('');
  const [attachment, setAttachment] = useState<Attachment | undefined>(undefined);
  const [error, setError] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) {
      setAttachment(undefined);
      return;
    }

    if (file.size > 5 * 1024 * 1024) { // 5MB limit check
      setError('O arquivo deve ter no máximo 5MB.');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    try {
      const base64 = await convertToBase64(file);
      setAttachment({
        name: file.name,
        mimeType: file.type,
        data: base64
      });
      setError('');
    } catch (err) {
      console.error(err);
      setError('Erro ao processar o arquivo.');
    }
  };

  const convertToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  // Calculate current total bank balance (Credits - Debits)
  const calculateBankBalance = (employeeId: string): number => {
    const employee = employees.find(e => e.id === employeeId);
    if (!employee) return 0;

    // Credits (BankHourHistory)
    let totalCreditsMinutes = 0;
    (employee.bankHourHistory || []).forEach(record => {
      totalCreditsMinutes += (record.hours * 60) + record.minutes;
    });

    // Debits (AlterationHistory where type is 'Folga')
    let totalDebitsMinutes = 0;
    (employee.alterationHistory || []).forEach(record => {
      if (record.type === 'Folga') {
        totalDebitsMinutes += ((record.hours || 0) * 60) + (record.minutes || 0);
      }
    });

    return totalCreditsMinutes - totalDebitsMinutes;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!selectedEmployeeId) {
      setError('Selecione um funcionário.');
      return;
    }
    
    // Date Validation
    const isRangeType = type === 'Atestado Médico' || type === 'Férias';

    if (!date) {
      setError(isRangeType ? 'Selecione a data inicial.' : 'Selecione a data da alteração.');
      return;
    }

    if (isRangeType) {
      if (!endDate) {
        setError('Selecione a data final.');
        return;
      }
      if (new Date(endDate) < new Date(date)) {
        setError('A data final não pode ser anterior à data inicial.');
        return;
      }

      // Validação Específica para Férias (Máximo 30 dias)
      if (type === 'Férias') {
        const start = new Date(date);
        const end = new Date(endDate);
        // Calcula diferença em milissegundos
        const diffTime = Math.abs(end.getTime() - start.getTime());
        // Converte para dias e soma 1 para contar o dia de início
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;

        if (diffDays > 30) {
          setError(`O período de férias não pode exceder 30 dias. O intervalo selecionado possui ${diffDays} dias.`);
          return;
        }
      }
    }

    let h = 0;
    let m = 0;

    if (type === 'Folga') {
      if (!hours && !minutes) {
        setError('Para lançar Folga, informe a quantidade de horas e/ou minutos a debitar.');
        return;
      }
      h = parseInt(hours || '0', 10);
      m = parseInt(minutes || '0', 10);

      if (h < 0 || m < 0) {
        setError('Valores não podem ser negativos.');
        return;
      }

      // Check Bank Balance
      const currentBalanceMinutes = calculateBankBalance(selectedEmployeeId);
      const debitMinutes = (h * 60) + m;
      const newBalance = currentBalanceMinutes - debitMinutes;

      if (newBalance < 0) {
        const confirmNegative = window.confirm(
          `ATENÇÃO: O banco de horas deste funcionário ficará negativo!\n\n` +
          `Saldo Atual: ${Math.floor(currentBalanceMinutes / 60)}h ${currentBalanceMinutes % 60}m\n` +
          `Débito: ${h}h ${m}m\n` +
          `Novo Saldo: ${Math.floor(newBalance / 60)}h ${Math.abs(newBalance % 60)}m\n\n` +
          `Deseja continuar mesmo assim?`
        );
        if (!confirmNegative) {
          return;
        }
      }
    }

    onSave(
      selectedEmployeeId, 
      date, 
      type, 
      type === 'Abono' ? abonoType : undefined, 
      reason,
      type === 'Atestado Médico' ? attachment : undefined,
      isRangeType ? endDate : undefined,
      type === 'Folga' ? h : undefined,
      type === 'Folga' ? m : undefined
    );
    
    // Reset fields
    setDate('');
    setEndDate('');
    setReason('');
    setHours('');
    setMinutes('');
    setAttachment(undefined);
    setError('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const shouldDeductWorkDay = () => {
    if (type === 'Falta' || type === 'Atestado Médico' || type === 'Férias') return true;
    if (type === 'Abono' && (abonoType === 'Doação de Sangue' || abonoType === 'TRE')) return true;
    return false;
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
      <EmployeeSelect
        employees={employees}
        value={selectedEmployeeId}
        onChange={setSelectedEmployeeId}
        disabled={disabled}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Tipo de Alteração
          </label>
          <select
            className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 bg-white"
            value={type}
            onChange={(e) => {
              setType(e.target.value as AlterationType);
              // Reset specific fields when type changes
              setAttachment(undefined);
              setEndDate('');
              setHours('');
              setMinutes('');
              if (fileInputRef.current) fileInputRef.current.value = '';
            }}
            disabled={disabled}
          >
            <option value="Falta">Falta</option>
            <option value="Atestado Médico">Atestado Médico</option>
            <option value="Férias">Férias</option>
            <option value="Abono">Abono</option>
            <option value="Folga">Folga (Débito Banco de Horas)</option>
          </select>
        </div>

        {type === 'Abono' && (
          <div className="animate-fade-in">
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Tipo de Abono
            </label>
            <select
              className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 bg-white"
              value={abonoType}
              onChange={(e) => setAbonoType(e.target.value as AbonoType)}
              disabled={disabled}
            >
              <option value="Audiência">Audiência</option>
              <option value="Aniversário">Aniversário</option>
              <option value="Doação de Sangue">Doação de Sangue</option>
              <option value="Preventivo">Preventivo</option>
              <option value="TRE">TRE</option>
            </select>
          </div>
        )}

        {/* Dynamic Date Inputs */}
        {type === 'Atestado Médico' || type === 'Férias' ? (
          <>
            <div className="animate-fade-in">
               <Input
                label="Data Inicial"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                disabled={disabled}
              />
            </div>
            <div className="animate-fade-in">
               <Input
                label="Data Final"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                disabled={disabled}
              />
            </div>
          </>
        ) : (
          <div className={type !== 'Abono' && type !== 'Folga' ? 'md:col-span-1' : 'md:col-span-2'}>
             <Input
              label="Data"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              disabled={disabled}
            />
          </div>
        )}

        {/* Folga Hours Inputs */}
        {type === 'Folga' && (
          <div className="md:col-span-2 grid grid-cols-2 gap-4 p-4 bg-blue-50 border border-blue-100 rounded-md animate-fade-in">
             <div className="col-span-2 text-sm text-blue-800 font-medium mb-1">
                Débito de Banco de Horas
             </div>
             <Input
               label="Horas"
               type="number"
               min="0"
               value={hours}
               onChange={(e) => setHours(e.target.value)}
               placeholder="0"
               disabled={disabled}
               className="mb-0"
             />
             <Input
               label="Minutos"
               type="number"
               min="0"
               max="59"
               value={minutes}
               onChange={(e) => setMinutes(e.target.value)}
               placeholder="0"
               disabled={disabled}
               className="mb-0"
             />
          </div>
        )}

        {type === 'Atestado Médico' && (
           <div className="md:col-span-2 animate-fade-in p-4 bg-slate-50 border border-slate-200 rounded-md">
             <label className="block text-sm font-medium text-slate-700 mb-1">
               Anexar Atestado (PDF ou Imagem)
             </label>
             <input
               ref={fileInputRef}
               type="file"
               accept="image/*,application/pdf"
               onChange={handleFileChange}
               disabled={disabled}
               className="block w-full text-sm text-slate-500
                 file:mr-4 file:py-2 file:px-4
                 file:rounded-md file:border-0
                 file:text-sm file:font-semibold
                 file:bg-brand-50 file:text-brand-700
                 hover:file:bg-brand-100"
             />
             <p className="mt-1 text-xs text-slate-500">
               Formatos aceitos: .jpg, .png, .pdf. Tamanho máx: 5MB.
             </p>
           </div>
        )}

        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Observação (Opcional)
          </label>
          <textarea
            className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 min-h-[100px]"
            placeholder="Descreva o motivo..."
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            disabled={disabled}
          />
        </div>
      </div>

      {error && <p className="mt-4 text-sm text-red-600">{error}</p>}

      <div className="mt-6 flex justify-between items-center">
         <div className="text-xs text-slate-500 italic max-w-xs">
            {type === 'Folga' 
               ? "* Este valor será debitado do saldo de Banco de Horas."
               : shouldDeductWorkDay() 
                  ? (type === 'Atestado Médico' || type === 'Férias')
                     ? "* Cada dia dentro do período será descontado dos dias trabalhados."
                     : "* Esta alteração abaterá 1 dia trabalhado do mês."
                  : "* Esta alteração NÃO abaterá dias trabalhados."
            }
         </div>
        <Button type="submit" disabled={disabled} variant="danger">
          Lançar Alteração
        </Button>
      </div>
    </form>
  );
};