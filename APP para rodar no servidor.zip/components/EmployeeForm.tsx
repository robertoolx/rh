import React, { useState } from 'react';
import { Employee, UserRole } from '../types';
import { Input } from './Input';
import { Button } from './Button';
import { formatCPF, validateCPF } from '../utils/validation';

interface EmployeeFormProps {
  onSave: (employee: Omit<Employee, 'id' | 'createdAt'>) => void;
  disabled?: boolean;
}

export const EmployeeForm: React.FC<EmployeeFormProps> = ({ onSave, disabled }) => {
  const [name, setName] = useState('');
  const [registrationNumber, setRegistrationNumber] = useState('');
  const [cpf, setCpf] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [admissionDate, setAdmissionDate] = useState('');
  const [role, setRole] = useState<UserRole>('Comum');
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCPF(e.target.value);
    setCpf(formatted);
    if (errors.cpf) {
      setErrors(prev => ({ ...prev, cpf: '' }));
    }
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!name.trim()) newErrors.name = 'Nome é obrigatório';
    if (!registrationNumber.trim()) newErrors.registrationNumber = 'Matrícula é obrigatória';
    if (!birthDate) newErrors.birthDate = 'Data de nascimento é obrigatória';
    if (!admissionDate) newErrors.admissionDate = 'Data de admissão é obrigatória';
    
    if (!cpf) {
      newErrors.cpf = 'CPF é obrigatório';
    } else if (!validateCPF(cpf)) {
      newErrors.cpf = 'CPF inválido';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    onSave({
      name,
      registrationNumber,
      cpf,
      birthDate,
      admissionDate,
      role
    });

    // Reset form
    setName('');
    setRegistrationNumber('');
    setCpf('');
    setBirthDate('');
    setAdmissionDate('');
    setRole('Comum');
    setErrors({});
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="md:col-span-2">
          <Input
            label="Nome Completo"
            value={name}
            onChange={(e) => setName(e.target.value)}
            error={errors.name}
            placeholder="Ex: João da Silva"
            disabled={disabled}
          />
        </div>

        <Input
          label="Matrícula"
          value={registrationNumber}
          onChange={(e) => setRegistrationNumber(e.target.value)}
          error={errors.registrationNumber}
          placeholder="Ex: 12345"
          disabled={disabled}
        />

        <Input
          label="CPF"
          value={cpf}
          onChange={handleCpfChange}
          error={errors.cpf}
          placeholder="000.000.000-00"
          maxLength={14}
          disabled={disabled}
        />

        <Input
          label="Data de Nascimento"
          type="date"
          value={birthDate}
          onChange={(e) => setBirthDate(e.target.value)}
          error={errors.birthDate}
          disabled={disabled}
        />

        <Input
          label="Data de Admissão"
          type="date"
          value={admissionDate}
          onChange={(e) => setAdmissionDate(e.target.value)}
          error={errors.admissionDate}
          disabled={disabled}
        />

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Nível de Permissão
          </label>
          <select
            className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 bg-white disabled:bg-slate-100 disabled:text-slate-500"
            value={role}
            onChange={(e) => setRole(e.target.value as UserRole)}
            disabled={disabled}
          >
            <option value="Comum">Comum</option>
            <option value="Administrador">Administrador</option>
          </select>
        </div>
      </div>

      <div className="mt-6 flex justify-end">
        <Button type="submit" disabled={disabled}>
          Salvar Funcionário
        </Button>
      </div>
    </form>
  );
};