import React, { useState } from 'react';
import { Employee } from '../types';
import { Input } from './Input';
import { Button } from './Button';
import { EmployeeSelect } from './EmployeeSelect';

interface TreFormProps {
  employees: Employee[];
  onSave: (employeeId: string, workDate: string, creditDays: number, observation: string) => void;
  disabled?: boolean;
}

export const TreForm: React.FC<TreFormProps> = ({ employees, onSave, disabled }) => {
  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [workDate, setWorkDate] = useState('');
  const [creditDays, setCreditDays] = useState('');
  const [observation, setObservation] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!selectedEmployeeId) {
      setError('Selecione um funcionário.');
      return;
    }
    if (!workDate) {
      setError('Selecione a data do trabalho eleitoral.');
      return;
    }
    if (!creditDays) {
      setError('Informe a quantidade de dias de crédito.');
      return;
    }
    
    const days = parseFloat(creditDays);
    if (days <= 0) {
       setError('A quantidade de dias deve ser maior que zero.');
       return;
    }

    onSave(selectedEmployeeId, workDate, days, observation);

    // Reset non-fixed fields
    setWorkDate('');
    setCreditDays('');
    setObservation('');
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
      <EmployeeSelect
        employees={employees}
        value={selectedEmployeeId}
        onChange={setSelectedEmployeeId}
        disabled={disabled}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Data do Trabalho Eleitoral"
          type="date"
          value={workDate}
          onChange={(e) => setWorkDate(e.target.value)}
          disabled={disabled}
        />
        <Input
          label="Dias de Crédito"
          type="number"
          min="0"
          step="0.5"
          value={creditDays}
          onChange={(e) => setCreditDays(e.target.value)}
          placeholder="Ex: 2"
          disabled={disabled}
        />
      </div>

      <div className="mt-4">
        <label className="block text-sm font-medium text-slate-700 mb-1">
          Observação (Opcional)
        </label>
        <textarea
          className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 min-h-[100px]"
          placeholder="Ex: 1º Turno das Eleições Municipais..."
          value={observation}
          onChange={(e) => setObservation(e.target.value)}
          disabled={disabled}
        />
      </div>

      {error && (
        <div className="mt-4 p-3 bg-red-50 text-red-700 text-sm rounded border border-red-200">
          {error}
        </div>
      )}

      <div className="mt-6 flex justify-between items-center">
         <div className="text-xs text-slate-500 max-w-sm">
             * Registra o crédito de dias concedidos pela justiça eleitoral.
         </div>
        <Button type="submit" disabled={disabled} variant="primary">
          Lançar TRE
        </Button>
      </div>
    </form>
  );
};